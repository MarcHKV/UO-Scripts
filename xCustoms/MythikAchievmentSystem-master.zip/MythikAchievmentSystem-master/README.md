Mythik Achievement System
=========================

### Installation


Installation should be as simple as drop it in your custom scripts folder.



### Adding Achievments

Currently there are Hunter, Resource gathering, Region discovery, and Item crafting Achievement types.

You must edit the AchievmentSystem.cs file there are comments and example entries included.

Once you have the system running do not change Achievment ID's as progress is stored tied to the ID not the actual achievement.


