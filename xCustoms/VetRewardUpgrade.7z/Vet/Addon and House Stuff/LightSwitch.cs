using System;
using System.Collections;
using Server.Items;
using Server.Multis;
using Server.Mobiles;
using Server.Network;

namespace Server.Items
{
    [Furniture]
    [Flipable(0x108F, 0x1092)]
    public class LightSwitch : Item
    {
        [Constructable]
        public LightSwitch()
            : base(0x108F)
        {
            Weight = 1.0;
        }

        public LightSwitch(Serial serial)
            : base(serial)
        {
        }

        public override void OnDoubleClick(Mobile from)
        {
            Switch(from);
        }

        public void Switch(Mobile from)
        {
            if (ItemID == 0x108F) ItemID = 0x1090;
            else if (ItemID == 0x1090) ItemID = 0x108F;
            else if (ItemID == 0x1092) ItemID = 0x1091;
            else if (ItemID == 0x1091) ItemID = 0x1092;
            BaseHouse house = BaseHouse.FindHouseAt(from);
            if (house != null && house.LockDowns.Contains(this))
            {
                foreach (Item i in house.LockDowns)
                {
                    if (i is BaseLight)
                    {
                        BaseLight b = i as BaseLight;
                        switch (ItemID)
                        {
                            case 0x108F:
                            case 0x1092: b.Ignite(); break;
                            case 0x1090:
                            case 0x1091: b.Douse(); break;
                        }
                    }
                }
            }
        }

        public override bool HandlesOnSpeech { get { return true; } }

        public override void OnSpeech(SpeechEventArgs e)
        {
            if (e.Speech.ToLower().Contains("clapon") || e.Speech.ToLower().Contains("clap on"))
            {
                if (ItemID == 0x1090 || ItemID == 0x1091) Switch(e.Mobile);
                e.Mobile.Animate(17, 5, 1, true, false, 0);
            }
            if (e.Speech.ToLower().Contains("clapoff") || e.Speech.ToLower().Contains("clap off"))
            {
                if (ItemID == 0x108F || ItemID == 0x1092) Switch(e.Mobile);
                e.Mobile.Animate(17, 5, 1, true, false, 0);
            }
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}