using System;
using Server;
using Server.Network;
using Server.Items;
using Server.Mobiles;
using Server.Prompts;

namespace Server.Items
{
        [FlipableAttribute( 0x13B2, 0x13B1 )]
        public class NeonWep1 : BaseRangedAmmoless
	{
		public override int EffectID{ get{return 0x3818; } }

      public override WeaponAbility PrimaryAbility{ get{ return WeaponAbility.ArmorIgnore; } }
      public override WeaponAbility SecondaryAbility{ get{ return WeaponAbility.MovingShot; } }

      //public override int AosStrengthReq{ get{ return 30; } }
      public override int AosIntelligenceReq{ get{ return 30; } }
      public override int AosMinDamage{ get{ return 13; } }
      public override int AosMaxDamage{ get{return 19; } }
      public override int AosSpeed{ get{return 25; } }

      public override int OldIntelligenceReq{ get{ return 20; } }
      public override int OldMinDamage{ get{return 11; } }
      public override int OldMaxDamage{ get{return 50; } }
      public override int OldSpeed{ get{return 30; } }

      public override int DefMaxRange{ get{return 10; } }

      public override WeaponAnimation DefAnimation{ get{ return WeaponAnimation.ShootBow; } }

    		private static int GetNeonHue()
    		{
			switch ( Utility.Random( 4 ) )
			{
				default:
				case 0: return 1170;
				case 1: return 1370;
				case 2: return 1161;
				case 3: return 1160;
			}
		}


		[Constructable]
		public NeonWep1() : base( 0x13B2 )
		{
			this.Weight = 9.0;
			this.Hue = GetNeonHue();
			this.Name = "A Neon Bow";
                        Identified = true;
                        this.Layer = Layer.TwoHanded;
                        this.LootType = LootType.Blessed;
                        this.Attributes.SpellChanneling = 1;
                        
			if (this.Hue == 1170)
				{
					this.WeaponAttributes.HitLightning = 100;
					//this.WeaponAttributes.HitEnergyArea = 25;
					this.Attributes.AttackChance = 35;
                                        this.Name = "Bow of Power";
				}
				else if (this.Hue == 1370)
				{
					this.WeaponAttributes.HitPoisonArea = 100;
                                        this.WeaponAttributes.ResistPoisonBonus = 50;
                                        this.Attributes.RegenHits = 3;
					this.Attributes.AttackChance = 35;
                                        this.Name = "Toxic Bow" ;
				}
				else if (this.Hue == 1161)
				{
                                        this.WeaponAttributes.HitEnergyArea = 100;
					this.Attributes.CastSpeed = 2;
					this.Attributes.CastRecovery = 2;
                                        this.Attributes.LowerRegCost = 20;
					this.Attributes.RegenMana = 8;
					this.Name = "Bow of Sorcery";
				}
				else if (this.Hue == 1160)
				{
					this.WeaponAttributes.HitColdArea = 100;
                                        this.WeaponAttributes.ResistColdBonus = 50;
                                        this.Attributes.RegenStam = 3;
					this.Attributes.AttackChance = 35;
					this.Name = "Freezing Bow";
				}
		}
  
                /*public override void GetDamageTypes( Mobile wielder, out int phys, out int fire, out int cold, out int pois, out int nrgy )
                {
                                if (this.Hue == 1170)
				{
					nrgy = fire = cold = pois = 0;
                                        phys = 100;
				}
				else if (this.Hue == 1370)
				{
					phys = fire = cold = nrgy = 0;
                                        pois = 100;
				}
				else if (this.Hue == 1161)
				{
					phys = fire = cold = pois = 0;
                                        nrgy = 100;
				}
				else if (this.Hue == 1160)
				{
					phys = fire = pois = nrgy = 0;
                                        cold = 100;
				}
      }*/
		/*public override void OnHit( Mobile attacker, Mobile defender )
		{
			if ( Utility.RandomDouble() >= 0.9 )
				if ( Utility.RandomDouble() >= 0.5 )
					if ( attacker.Criminal )
						Spawnhell( attacker );
			base.OnHit( attacker, defender );
		}*/

		/*public override void OnDoubleClick( Mobile from )
		{
		}*/

		/*public void Spawnhell( Mobile from )
		{
			BaseCreature hell;
			hell = new VengefullSpirit();
			hell.Map = from.Map;
			hell.Location = from.Location;
			hell.Combatant = from;
		}*/

		public NeonWep1( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
 }
