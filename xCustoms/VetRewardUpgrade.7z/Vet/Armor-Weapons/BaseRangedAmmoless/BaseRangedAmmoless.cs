using System;
using Server.Items;
using Server.Network;

namespace Server.Items
{
   public abstract class BaseRangedAmmoless : BaseMeleeWeapon
   {
      public abstract int EffectID{ get; }

      public override int DefHitSound{ get{ return 0x234; } }
      public override int DefMissSound{ get{ return 0x238; } }

      public override SkillName DefSkill{ get{ return SkillName.Archery; } }
      public override WeaponType DefType{ get{ return WeaponType.Ranged; } }
      public override WeaponAnimation DefAnimation{ get{ return WeaponAnimation.ShootXBow; } }

      public BaseRangedAmmoless( int itemID ) : base( itemID )
      {

      }

      public BaseRangedAmmoless( Serial serial) : base( serial)
      {

      }

      public override TimeSpan OnSwing( Mobile attacker, Mobile defender )
      {
         // Make sure we've been standing still for one second ( Reduced 50% )
          if (Core.TickCount > (attacker.LastMoveTime + (int)TimeSpan.FromSeconds(.5).TotalMilliseconds) || (Core.AOS && WeaponAbility.GetCurrentAbility(attacker) is MovingShot))
         {
            if ( attacker.HarmfulCheck( defender ) )
            {
               attacker.DisruptiveAction();
               attacker.Send( new Swing( 0, attacker, defender ) );

               if ( OnFired( attacker, defender ) )
               {
                  if ( CheckHit( attacker, defender ) )
                     OnHit( attacker, defender );
                  else
                     OnMiss( attacker, defender );
               }

            }

            return GetDelay( attacker );

         }
         else
         {
            return TimeSpan.FromSeconds( 0.25 );
         }
      }

      /*public override void OnHit( Mobile attacker, Mobile defender )
      {
         base.OnHit( attacker, defender );
      }*/

      public override void OnMiss( Mobile attacker, Mobile defender )
      {
         base.OnMiss( attacker, defender );
      }

      public virtual bool OnFired( Mobile attacker, Mobile defender )
      {
         attacker.MovingEffect( defender, EffectID, 18, 1, false, false );

         return true;
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );

         writer.Write( (int) 1 ); // version

      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader);

         int version = reader.ReadInt();

         switch ( version )
         {
            case 1:
               {
                  break;
               }
            case 0:
               {
                  /*m_EffectID =*/ reader.ReadInt();
                  break;
               }
         }
      }
   }
}

