/*

Rune Magic System by Alari
(delete the older runebag.cs)

Place runes in runebag, single click to cast.

*/

using System;
using System.Collections;
using System.Collections.Generic;
using Server.Multis;
using Server.Mobiles;
using Server.Network;
using Server.ContextMenus;
using Server.Spells;

namespace Server.Items
{
	public class RuneBag : BaseContainer
	{
		public override int DefaultGumpID{ get{ return 0x3D; } }
		public override int DefaultDropSound{ get{ return 0x48; } }

		public override Rectangle2D Bounds
		{
			get{ return new Rectangle2D( 29, 34, 108, 94 ); }
		}

		[Constructable]
		public RuneBag() : base( 0xE76 )
		{
			Name = "rune bag";
			Weight = 1.0;
			LootType = LootType.Blessed;
			Hue = Utility.RandomBirdHue();
		}

		public override bool DisplayLootType{ get{ return false; } }

		public void RuneBagCast( Mobile m, RuneBag bag )
		{

// descs from U6. For reference.
// I've left in my notes for rareness, this is custom to my shard.

			bool foundAn	= false; // Negate/Dispel	- common
			bool foundBet	= false; // Small		- semi-common
			bool foundCorp	= false; // Death		- rare
			bool foundDes	= false; // Lower/Down		- semi-common
			bool foundEx	= false; // Freedom		- semi-common
			bool foundFlam	= false; // Flame		- semi-common
			bool foundGrav	= false; // Energy/Field	- rare
			bool foundHur	= false; // Wind		- semi-common
			bool foundIn	= false; // Make/Create/Cause	- common
			bool foundJux	= false; // Danger/Trap/Harm	- semi-common
			bool foundKal	= false; // Summon/Invoke	- common
			bool foundLor	= false; // Light		- common
			bool foundMani	= false; // Life/Healing	- common
			bool foundNox	= false; // Poison		- semi-common
			bool foundOrt	= false; // Magic		- semi-common
			bool foundPor	= false; // Move/Movement	- semi-common
			bool foundQuas	= false; // Illusion		- semi-common
			bool foundRel	= false; // Change		- common
			bool foundSanct	= false; // Protect/Protection	- semi-common
			bool foundTym	= false; // Time		- rare
			bool foundUus	= false; // Raise/Up		- semi-common
			bool foundVas	= false; // Great		- rare
			bool foundWis	= false; // Know/Knowledge	- semi-common
			bool foundXen	= false; // Creature		- semi-common
			bool foundYlem	= false; // Matter		- semi-common
			bool foundZu	= false; // Sleep		- semi-common

			foreach( Item I in bag.Items ) 
			{ 
				if ( I is An )
					foundAn		= true;
				if ( I is Bet )
					foundBet	= true;
				if ( I is Corp )
					foundCorp	= true;
				if ( I is Des )
					foundDes	= true;
				if ( I is Ex )
					foundEx		= true;
				if ( I is Flam )
					foundFlam	= true;
				if ( I is Grav )
					foundGrav	= true;
				if ( I is Hur )
					foundHur	= true;
				if ( I is In )
					foundIn		= true;
				if ( I is Jux )
					foundJux	= true;
				if ( I is Kal )
					foundKal	= true;
				if ( I is Lor )
					foundLor	= true;
				if ( I is Mani )
					foundMani	= true;
				if ( I is Nox )
					foundNox	= true;
				if ( I is Ort )
					foundOrt	= true;
				if ( I is Por )
					foundPor	= true;
				if ( I is Quas )
					foundQuas	= true;
				if ( I is Rel )
					foundRel	= true;
				if ( I is Sanct )
					foundSanct	= true;
				if ( I is Tym )
					foundTym	= true;
				if ( I is Uus )
					foundUus	= true;
				if ( I is Vas )
					foundVas	= true;
				if ( I is Wis )
					foundWis	= true;
				if ( I is Xen )
					foundXen	= true;
				if ( I is Ylem )
					foundYlem	= true;
				if ( I is Zu )
					foundZu		= true;
			}


			int m_SpellID = -1;  // no match


/// spells go here.  ////////////////////////////////////////////
/*
			if ( ( found ) ) && bag.Items.Count ==  )
				m_SpellID = ;
*/



///  first circle   /////////////////////////////////////////////


// clumsy: Uus Jux
			if ( ( foundUus && foundJux ) && bag.Items.Count == 2 )
				m_SpellID = 0;

// Create food: In Mani Ylem
			if ( ( foundIn && foundMani && foundYlem ) && bag.Items.Count == 3 )
				m_SpellID = 1;

// Feeblemind: Rel Wis
			if ( ( foundRel && foundWis ) && bag.Items.Count == 2 )
				m_SpellID = 2;

// Heal: In Mani
			if ( ( foundIn && foundMani ) && bag.Items.Count == 2 )
				m_SpellID = 3;

// Magic arrow: In Por Ylem
			if ( ( foundIn && foundPor && foundYlem ) && bag.Items.Count == 3 )
				m_SpellID = 4;

// Night sight: In Lor
			if ( ( foundIn && foundLor ) && bag.Items.Count == 2 )
				m_SpellID = 5;

// Reactive armor: Flam Sanct
			if ( ( foundFlam && foundSanct ) && bag.Items.Count == 2 )
				m_SpellID = 6;

// Weaken: Des Mani
			if ( ( foundDes && foundMani ) && bag.Items.Count == 2 )
				m_SpellID = 7;



///  second circle   ///////////////////////////////////////////////


// Agility: Ex Uus
			if ( ( foundUus && foundEx ) && bag.Items.Count == 2 )
				m_SpellID = 8;

// Cunning: Uus Wis
			if ( ( foundUus && foundWis ) && bag.Items.Count == 2 )
				m_SpellID = 9;

// Cure: An Nox
			if ( ( foundAn && foundNox ) && bag.Items.Count == 2 )
				m_SpellID = 10;

// Harm: An Mani
			if ( ( foundAn && foundMani ) && bag.Items.Count == 2 )
				m_SpellID = 11;

// Magic Trap: In Jux
			if ( ( foundIn && foundJux ) && bag.Items.Count == 2 )
				m_SpellID = 12;

// Magic Untrap: An Jux
			if ( ( foundAn && foundJux ) && bag.Items.Count == 2 )
				m_SpellID = 13;

// Protection: Uus Sanct
			if ( ( foundUus && foundSanct ) && bag.Items.Count == 2 )
				m_SpellID = 14;

// Strength: Uus Mani
			if ( ( foundUus && foundMani ) && bag.Items.Count == 2 )
				m_SpellID = 15;



///  Third circle   ////////////////////////////////////////////

// Bless: Rel Sanct
			if ( ( foundRel && foundSanct ) && bag.Items.Count == 2 )
				m_SpellID = 16;

// Fireball: Vas Flam
			if ( ( foundVas && foundFlam ) && bag.Items.Count == 2 )
				m_SpellID = 17;

// Magic Lock: An Por
			if ( ( foundAn && foundPor ) && bag.Items.Count == 2 )
				m_SpellID = 18;

// Poison: In Nox
			if ( ( foundIn && foundNox ) && bag.Items.Count == 2 )
				m_SpellID = 19;

// Telekinesis: Ort Por Ylem
			if ( ( foundOrt && foundPor && foundYlem ) && bag.Items.Count == 3 )
				m_SpellID = 20;

// Teleport: Rel Por
			if ( ( foundRel && foundPor ) && bag.Items.Count == 2 )
				m_SpellID = 21;

// Unlock: Ex Por
			if ( ( foundEx && foundPor ) && bag.Items.Count == 2 )
				m_SpellID = 22;

// Wall of Stone: In Sanct Ylem
			if ( ( foundIn && foundSanct && foundYlem ) && bag.Items.Count == 3 )
				m_SpellID = 23;



///  Fourth circle   ////////////////////////////////////////////


// Arch Cure: Vas An Nox
			if ( ( foundVas && foundAn && foundNox ) && bag.Items.Count == 3 )
				m_SpellID = 24;

// Arch Protection: Vas Uus Sanct
			if ( ( foundVas && foundUus && foundSanct ) && bag.Items.Count == 3 )
				m_SpellID = 25;

// Curse: Des Sanct
			if ( ( foundDes && foundSanct ) && bag.Items.Count == 2 )
				m_SpellID = 26;

// Fire Field: In Flam Grav
			if ( ( foundIn && foundFlam && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 27;

// Greater Heal: In Vas Mani
			if ( ( foundIn && foundVas && foundMani ) && bag.Items.Count == 3 )
				m_SpellID = 28;

// Lightning: Por Ort Grav
			if ( ( foundPor && foundOrt && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 29;

// Mana Drain: Ort Rel
			if ( ( foundOrt && foundRel ) && bag.Items.Count == 2 )
				m_SpellID = 30;

// Recall: Kal Ort Por
			if ( ( foundKal && foundOrt && foundPor ) && bag.Items.Count == 3 )
				m_SpellID = 31;



/// Fifth  circle   ////////////////////////////////////////////


// Blade Spirits: In Jux Hur Ylem
			if ( ( foundIn && foundJux && foundHur && foundYlem ) && bag.Items.Count == 4 )
				m_SpellID = 32;

// Dispel Field: An Grav
			if ( ( foundAn && foundGrav ) && bag.Items.Count == 2 )
				m_SpellID = 33;

// Incognito: Kal In Ex
			if ( ( foundKal && foundIn && foundEx ) && bag.Items.Count == 3 )
				m_SpellID = 34;

// Magic Reflection: In Jux Sanct
			if ( ( foundIn && foundJux && foundSanct ) && bag.Items.Count == 3 )
				m_SpellID = 35;

// Mind Blast: Por Corp Wis
			if ( ( foundPor && foundCorp && foundWis ) && bag.Items.Count == 3 )
				m_SpellID = 36;

// Paralyze: An Ex Por
			if ( ( foundAn && foundEx && foundPor ) && bag.Items.Count == 3 )
				m_SpellID = 37;

// PoisonField: In Nox Grav
			if ( ( foundIn && foundNox && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 38;

// Summon Creature: Kal Xen
			if ( ( foundKal && foundXen ) && bag.Items.Count == 2 )
				m_SpellID = 39;



/// Sixth  circle   ////////////////////////////////////////////


// Dispel: An Ort
			if ( ( foundAn && foundOrt ) && bag.Items.Count == 2 )
				m_SpellID = 40;

// Eenrgy Bolt: Corp Por
			if ( ( foundCorp && foundPor ) && bag.Items.Count == 2 )
				m_SpellID = 41;

// Explosion: Vas Ort Flam
			if ( ( foundVas && foundOrt && foundFlam ) && bag.Items.Count == 3 )
				m_SpellID = 42;

// Invisibility: An Lor Xen
			if ( ( foundAn && foundLor && foundXen ) && bag.Items.Count == 3 )
				m_SpellID = 43;

// Mark: Kal Por Ylem
			if ( ( foundKal && foundPor && foundYlem ) && bag.Items.Count == 3 )
				m_SpellID = 44;

// Mass Curse: Vas Des Sanct
			if ( ( foundVas && foundDes && foundSanct ) && bag.Items.Count == 3 )
				m_SpellID = 45;

// Paralyze Field: In Ex Grav
			if ( ( foundIn && foundEx && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 46;

// Reveal: Wis Quas
			if ( ( foundWis && foundQuas ) && bag.Items.Count == 2 )
				m_SpellID = 47;



/// Seventh  circle   ////////////////////////////////////////////


// Chain Lightning: Vas Ort Grav
			if ( ( foundVas && foundOrt && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 48;

// Energy Field: In Sanct Grav
			if ( ( foundIn && foundSanct && foundGrav ) && bag.Items.Count == 3 )
				m_SpellID = 49;

// Flame Strike: Kal Vas Flam
			if ( ( foundKal && foundVas && foundFlam ) && bag.Items.Count == 3 )
				m_SpellID = 50;

// Gate Travel: Vas Rel Por
			if ( ( foundVas && foundRel && foundPor ) && bag.Items.Count == 3 )
				m_SpellID = 51;

// Mana Vampire: Ort Sanct
			if ( ( foundOrt && foundSanct ) && bag.Items.Count == 2 )
				m_SpellID = 52;

// Mass Dispel: Vas An Ort
			if ( ( foundVas && foundAn && foundOrt ) && bag.Items.Count == 3 )
				m_SpellID = 53;

// Meteor Swarm: Flam Kal Des Ylem
			if ( ( foundFlam && foundKal && foundDes && foundYlem ) && bag.Items.Count == 4 )
				m_SpellID = 54;

// Polymorph: Vas Ylem Rel
			if ( ( foundVas && foundYlem && foundRel ) && bag.Items.Count == 3 )
				m_SpellID = 55;


// Captain the First was the First one to code the 8th circle spells and publish them!
/// Eighth  circle   //////////////////////////////////////////// 

// "Earthquake", "In Vas Por" 
         if ( ( foundIn && foundVas && foundPor ) && bag.Items.Count == 3 ) 
            m_SpellID = 56; 

// "Energy Vortex", "Vas Corp Por" 
         if ( ( foundVas && foundCorp && foundPor ) && bag.Items.Count == 3 ) 
            m_SpellID = 57; 

// "Resurrection", "An Corp" 
         if ( ( foundAn && foundCorp ) && bag.Items.Count == 2 ) 
            m_SpellID = 58; 

// "Air Elemental", "Kal Vas Xen Hur" 
         if ( ( foundKal && foundVas && foundXen && foundHur ) && bag.Items.Count ==  4 ) 
            m_SpellID = 59; 

// "Summon Daemon", "Kal Vas Xen Corp" 
         if ( ( foundKal && foundVas && foundXen && foundCorp ) && bag.Items.Count ==  4 ) 
            m_SpellID = 60; 

// "Earth Elemental", "Kal Vas Xen Ylem" 
         if ( ( foundKal && foundVas && foundXen && foundYlem ) && bag.Items.Count ==  4 ) 
            m_SpellID = 61; 

// "Fire Elemental", "Kal Vas Xen Flam" 
         if ( ( foundKal && foundVas && foundXen && foundFlam ) && bag.Items.Count ==  4 ) 
            m_SpellID = 62; 

// "Water Elemental", "Kal Vas Xen An Flam" 
         if ( ( foundKal && foundVas && foundXen && foundAn && foundFlam ) && bag.Items.Count ==  5 ) 
            m_SpellID = 63; 




/// end spells /////////////////////////////////////

/// end spells /////////////////////////////////////


/// begin spellcasting /////////////////////////////


			if ( !Multis.DesignContext.Check( m ) )
				return; // They are customizing

			if ( !IsChildOf( m.Backpack ) )
			{
				m.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.
				return;
			}

			if ( m_SpellID == -1 )
			{
				m.SendMessage( "Not a valid spell" );
				return;
			}

			Spell spell = SpellRegistry.NewSpell( m_SpellID, m, this );

			if ( spell != null )
				spell.Cast();
			else
				m.SendLocalizedMessage( 502345 ); // This spell has been temporarily disabled.



		}


		public class RuneBagMenu : ContextMenuEntry 
		{ 
			private RuneBag i_RuneBag; 
			private Mobile m_Caster; 

			public RuneBagMenu( Mobile from, RuneBag bag ) : base( 2090, 1 ) 
			{ 
				m_Caster = from; 
				i_RuneBag = bag; 
			} 

			public override void OnClick() 
			{          
				if( i_RuneBag.IsChildOf( m_Caster.Backpack ) ) 
				{ 
					i_RuneBag.RuneBagCast( m_Caster, i_RuneBag );
				} 
				else 
				{ 
					m_Caster.SendLocalizedMessage( 1060640 );   // That item must be in your backpack to be used.
				} 
			} 
		} 

		public override void GetContextMenuEntries( Mobile from, List<ContextMenuEntry> list )
		{
			base.GetContextMenuEntries( from, list );

			if ( from.Alive )
				list.Add( new RuneBagMenu( from, this ) );
		}


		public RuneBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}


///  Full Rune Bag ///////////////////////////////////////////

	public class FullRuneBag : Bag
	{
		[Constructable]
		public FullRuneBag() : base()
		{
			Name = "Full Rune Bag";
			Hue = Utility.RandomMetalHue();
			LootType = LootType.Blessed;

			PlaceItemIn( this, 30, 35, new An()	);
			PlaceItemIn( this, 40, 35, new Bet()	);
			PlaceItemIn( this, 50, 35, new Corp()	);
			PlaceItemIn( this, 60, 35, new Des()	);
			PlaceItemIn( this, 70, 35, new Ex()	);
			PlaceItemIn( this, 80, 35, new Flam()	);
			PlaceItemIn( this, 90, 35, new Grav()	);

			PlaceItemIn( this, 30, 50, new Hur()	);
			PlaceItemIn( this, 40, 50, new In()	);
			PlaceItemIn( this, 50, 50, new Jux()	);
			PlaceItemIn( this, 60, 50, new Kal()	);
			PlaceItemIn( this, 70, 50, new Lor()	);
			PlaceItemIn( this, 80, 50, new Mani()	);
			PlaceItemIn( this, 90, 50, new Nox()	);

			PlaceItemIn( this, 30, 65, new Ort()	);
			PlaceItemIn( this, 40, 65, new Por()	);
			PlaceItemIn( this, 50, 65, new Quas()	);
			PlaceItemIn( this, 60, 65, new Rel()	);
			PlaceItemIn( this, 70, 65, new Sanct()	);
			PlaceItemIn( this, 80, 65, new Tym()	);
			PlaceItemIn( this, 90, 65, new Uus()	);

			PlaceItemIn( this, 30, 80, new Vas()	);
			PlaceItemIn( this, 40, 80, new Wis()	);
			PlaceItemIn( this, 50, 80, new Xen()	);
			PlaceItemIn( this, 60, 80, new Ylem()	);
			PlaceItemIn( this, 70, 80, new Zu()	);

			PlaceItemIn( this, 70, 100, new RuneMagicBook() );
			PlaceItemIn( this, 80, 100, new RuneBag() );
                        PlaceItemIn( this, 90, 100, new RuneBag() );
		}

		private static void PlaceItemIn( Container parent, int x, int y, Item item )
		{
			parent.AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public override bool DisplayLootType{ get{ return false; } }

		public FullRuneBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}


///////////// Runestones ///////////////

/// base runestone

	public abstract class RuneStone : Item
	{
		public RuneStone() : base( 0x1F14 )
		{
			LootType = LootType.Blessed;
		//	Weight = 0.01;  // ?
			Weight = 0;  // ?
		//	Hue = 942;
		//	Hue = Utility.RandomBirdHue();

			switch ( Utility.Random( 1, 15 ) )
			{
				case 1:
				Hue = Utility.RandomNeutralHue();
				break;

				case 2:
			//	Hue = Utility.RandomDyedHue();
			//	break;

				case 3:
				Hue = Utility.RandomNondyedHue();
				break;

				case 4:
				Hue = Utility.RandomRedHue();
				break;

				case 5:
				Hue = Utility.RandomPinkHue();
				break;

				case 6:
				Hue = Utility.RandomYellowHue();
				break;

				case 7:
				Hue = Utility.RandomGreenHue();
				break;

				case 8:
				Hue = Utility.RandomBlueHue();
				break;
	
				case 9:
			//	Hue = Utility.RandomSkinHue();
			//	break;	
	
				case 10:
			//	Hue = Utility.RandomHairHue();
			//	break;	

				case 11:
				Hue = Utility.RandomAnimalHue();
				break;	

				case 12:
				Hue = Utility.RandomBirdHue();
				break;	
	
				case 13:
				Hue = Utility.RandomSlimeHue();
				break;	

				case 14:
				Hue = Utility.RandomSnakeHue();
				break;	

				case 15:
				Hue = Utility.RandomMetalHue();
				break;	
			}
		}

		public override bool DisplayLootType{ get{ return false; } }  // ha ha!

		public RuneStone( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}


///////////////////////////////////////////////////
/// end base runestone. Custom runestones below ///
///////////////////////////////////////////////////

	public class An : RuneStone
	{
		[Constructable]
		public An() : base()
		{
			Name = "An rune stone";
			Hue = Utility.RandomSlimeHue();
		}
	
		public An( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Bet : RuneStone
	{
		[Constructable]
		public Bet() : base()
		{
			Name = "Bet rune stone";
			Hue = Utility.RandomSnakeHue();
		}
	
		public Bet( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Corp : RuneStone
	{
		[Constructable]
		public Corp() : base()
		{
			Name = "Corp rune stone";
			Hue = Utility.RandomRedHue();
		}
	
		public Corp( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Des : RuneStone
	{
		[Constructable]
		public Des() : base()
		{
			Name = "Des rune stone";
			Hue = Utility.RandomMetalHue();
		}
	
		public Des( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Ex : RuneStone
	{
		[Constructable]
		public Ex() : base()
		{
			Name = "Ex rune stone";
			Hue = Utility.RandomYellowHue();
		}
	
		public Ex( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}


	public class Flam : RuneStone
	{
		[Constructable]
		public Flam() : base()
		{
			Name = "Flam rune stone";
			switch ( Utility.Random( 1, 2 ) )
			{
				case 1:
				Hue = Utility.RandomRedHue();
				break;

				case 2:
				Hue = Utility.RandomYellowHue();
				break;
			}
		}
	
		public Flam( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Grav : RuneStone
	{
		[Constructable]
		public Grav() : base()
		{
			Name = "Grav rune stone";
			Hue = Utility.RandomGreenHue();
		}
	
		public Grav( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Hur : RuneStone
	{
		[Constructable]
		public Hur() : base()
		{
			Name = "Hur rune stone";
			Hue = Utility.RandomBlueHue();
		}
	
		public Hur( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class In : RuneStone
	{
		[Constructable]
		public In() : base()
		{
			Name = "In rune stone";
			Hue = Utility.RandomAnimalHue();
		}
	
		public In( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Jux : RuneStone
	{
		[Constructable]
		public Jux() : base()
		{
			Name = "Jux rune stone";
			Hue = Utility.RandomRedHue();
		}
	
		public Jux( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Kal : RuneStone
	{
		[Constructable]
		public Kal() : base()
		{
			Name = "Kal rune stone";
			Hue = Utility.RandomBirdHue();
		}
	
		public Kal( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Lor : RuneStone
	{
		[Constructable]
		public Lor() : base()
		{
			Name = "Lor rune stone";
			Hue = Utility.RandomYellowHue();
		}
	
		public Lor( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Mani : RuneStone
	{
		[Constructable]
		public Mani() : base()
		{
			Name = "Mani rune stone";
			Hue = Utility.RandomPinkHue();
		}

		public Mani( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Nox : RuneStone
	{
		[Constructable]
		public Nox() : base()
		{
			Name = "Nox rune stone";
			Hue = Utility.RandomGreenHue();
		}
	
		public Nox( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Ort : RuneStone
	{
		[Constructable]
		public Ort() : base()
		{
			Name = "Ort rune stone";
			Hue = Utility.RandomBlueHue();
		}
	
		public Ort( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Por : RuneStone
	{
		[Constructable]
		public Por() : base()
		{
			Name = "Por rune stone";
			Hue = Utility.RandomPinkHue();
		}
	
		public Por( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Quas : RuneStone
	{
		[Constructable]
		public Quas() : base()
		{
			Name = "Quas rune stone";
			Hue = Utility.RandomBlueHue();
		}
	
		public Quas( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Rel : RuneStone
	{
		[Constructable]
		public Rel() : base()
		{
			Name = "Rel rune stone";
			Hue = Utility.RandomSlimeHue();
		}
	
		public Rel( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Sanct : RuneStone
	{
		[Constructable]
		public Sanct() : base()
		{
			Name = "Sanct rune stone";
			Hue = Utility.RandomMetalHue();
		}
	
		public Sanct( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Tym : RuneStone
	{
		[Constructable]
		public Tym() : base()
		{
			Name = "Tym rune stone";
			Hue = Utility.RandomRedHue();
		}
	
		public Tym( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Uus : RuneStone
	{
		[Constructable]
		public Uus() : base()
		{
			Name = "Uus rune stone";
			Hue = Utility.RandomMetalHue();
		}
	
		public Uus( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Vas : RuneStone
	{
		[Constructable]
		public Vas() : base()
		{
			Name = "Vas rune stone";
			Hue = Utility.RandomRedHue();
		}
	
		public Vas( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Wis : RuneStone
	{
		[Constructable]
		public Wis() : base()
		{
			Name = "Wis rune stone";
			Hue = Utility.RandomBlueHue();
		}
	
		public Wis( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Xen : RuneStone
	{
		[Constructable]
		public Xen() : base()
		{
			Name = "Xen rune stone";
			Hue = Utility.RandomAnimalHue();
		}
	
		public Xen( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Ylem : RuneStone
	{
		[Constructable]
		public Ylem() : base()
		{
			Name = "Ylem rune stone";
			Hue = Utility.RandomBirdHue();
		}
	
		public Ylem( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Zu : RuneStone
	{
		[Constructable]
		public Zu() : base()
		{
			Name = "Zu rune stone";
			Hue = Utility.RandomMetalHue();
		}
	
		public Zu( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

/// rune magic book ^.^
/// alter to fit the RP and world setting of your shard, obviously.
/// This is just a very generic basis to work with.

	// [TypeAlias( "Server.Items.RuneBagBook" )]  // why doesn't this work?
	public class RuneMagicBook : BlueBook
	{
		[Constructable]
		public RuneMagicBook() : base( "Rune Magic", "Alari", 50, true ) // writable so players can make notes
		{
			// Hue = 718;  //? Utility.RandomHue(); ?
			Hue = Utility.RandomBirdHue();

			// NOTE: There are 8 lines per page and 
			// approx 22 to 24 characters per line! 
			//	0----+----1----+----2----+ 
			int cnt = 0; 
			string[] lines; 
			lines = new string[] 
			{ 
				"     Rune Magic", 
				"      by Alari", 
				"", 
				"The following is a short", 
				"description of rune magic,", 
				"the known spells, and the",
				"meanings of runes.",
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"     Rune Bags", 
				"", 
				"Rune bags and runes are", 
				"imbued with the power to", 
				"assist the caster in the", 
				"casting of a spell without", 
				"the need of reagents.", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				"", 
				"Place one of each", 
				"required rune stone", 
				"inside the rune bag,", 
				"and concentrate on the", 
				"incantation of the spell.", 
				"[click on the bag]", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"Following is a complete", 
				"list of all known spells", 
				"and the runes needed to", 
				"cast them.", 
				"Note that even with the", 
				"runes, a mage must still", 
				"have the will and power", 
				"to cast the spell.", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"First Circle", 
				" Clumsy", 
				"    In Jux", 
				"",
				"",
				" Create Food", 
				"    In Mani Ylem", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				" Feeblemind", 
				"    Rel Wis", 
				"",
				"",
				" Heal", 
				"    In Mani", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				" Magic Arrow", 
				"    In Por Ylem", 
				"",
				"",
				" Night Sight", 
				"    In Lor", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				" Reactive Armor", 
				"    Flam Sanct", 
				"",
				"", 
				" Weaken", 
				"    Des Mani", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				"[some pages have been", 
				"torn out of this volume]", 
				"", 
				"", 
				"[the work continues with", 
				"the meanings of the runes]", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"  Meanings of Runes", 
				"", 
				"An   - Negate/Dispel", 
				"Bet  - Small", 
				"Corp - Death", 
				"Des  - Lower/Down", 
				"Ex   - Freedom", 
				"Flam - Flame", 
			}; 
			Pages[cnt++].Lines = lines; 

			lines = new string[] 
			{ 
				"Grav - Energy/Field", 
				"Hur  - Wind", 
				"In   - Make/Create/Cause", 
				"Jux  - Danger/Trap/Harm", 
				"Kal  - Summon/Invoke", 
				"Lor  - Light", 
				"Mani - Life/Healing", 
				"Nox  - Poison", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"Ort  - Magic", 
				"Por  - Move/Movement", 
				"Quas - Illusion", 
				"Rel  - Change", 
				"Sanct- Protection", 
				"Tym  - Time", 
				"Uus  - Raise/Up", 
				"Vas  - Great", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"Wis  - Knowledge", 
				"Xen  - Creature", 
				"Ylem - Matter", 
				"Zu   - Sleep", 
				"", 
				"Runes must be used in", 
				"combinations to form", 
				"spells of power!", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				"The meanings are the key!", 
				"", 
				"", 
				"The following pages have", 
				"been left blank for thee", 
				"to take thy notes here.", 
				"", 
			}; 
			Pages[cnt++].Lines = lines;

			lines = new string[] 
			{ 
				"", 
				"Have fun discovering", 
				"the other spells.", 
				"", 
				"Best of luck in", 
				"thy experiments!", 
				"", 
				" - Alari", 

			}; 
			Pages[cnt++].Lines = lines;
		}

		public RuneMagicBook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}






// obsolete: old constructor due to renaming to runemagic book.
// TYPE ALIAS DOES NOT WORK!!!!!!111111ONEONEoneONEONE!1111!!!!111!!!!!!!! *twitch*
// whhhhhhyyyyyyyyyyyyyyyyyyyyy does typealias not work? =( =( =( =( =( =( =( =( =( =(

// and why the FUCK does this give me errors for [Constructable]?
// A: becauce C# gives errors for the WRONG FUCKING LINE!
//    the problem was in the serial method

	public class RuneBagBook : RuneMagicBook
	{
		[Constructable]
		public RuneBagBook() : base()
		{
		}

		public RuneBagBook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}








/* TH-TH-TH-THAT'S ALL, FOLKS! *
 *                             *
 *                             *
 *                             *
 * ...                         *
 * md PaganSorcery             *
 * >=)                         *
 *                             */

}
