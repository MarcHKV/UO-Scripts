Rune Magic System readme by Alari


Captain the First was the First one to code the 8th circle spells and publish them!
http://www.runuo.com/forum/viewtopic.php?t=24984


This is a recreation of the rune bags and runes from Ultima Underworld
(which still rocks =)

With this, you can cast spells by placing the runes in the rune bag,
single-clicking on the bag, and choosing "Cast Spell" (your only
choice ;)   These spells will not require reagents, will use less mana
by default, and neither your runes nor your runebag are lost during the
casting.


example spell: In Mani Ylem - Create Food.

Add "In()", "Mani()", and "Ylem()" to the runebag, and single-click it.



Installation: Put it somewhere under scripts. Scripts/Custom is good.

Adding it in game:

   [add RuneBag
   [add RuneMagicBook
   [add An
   [add Bet
   [add Corp

etc etc for each rune. They can be spawned on spawners normally.

Also for GMs or whatever:
   [add FullRuneBag
gives all runestones plus a runebag and the book. For testing or nuking
players. >=)


All items can be sold on vendors. The format of the genericbuyinfo string is:

  Add( new GenericBuyInfo( typeof( [Rune] ), [Price], [Qty], [ItemID:0x1F14], [Hue] ) );


So, for example, to add runes to a vendor, add these lines to their buy list:

  Add( new GenericBuyInfo( typeof( Corp ), 100, 10, 0x1F14, Utility.RandomRedHue() ) );

or

  Add( new GenericBuyInfo( typeof( In ), 15, 10, 0x1F14, Utility.RandomBirdHue() ) );



This package comes with OSI spells from the first to the seventh circle.
Eighth circle spells would be about as hard to script as paint-by-numbers,
in fact I've already filled in the numbers. ;) The spells aren't hard
to script. Below is an example spell:


// Create food: In Mani Ylem
if ( ( foundIn && foundMani && foundYlem ) && bag.Items.Count == 3 )
   m_SpellID = 1;


Yep that's it. Just a found[Rune] for every rune in the spell, and
bag.Items.Count == # of runes needed for spell. Set m_SpellID to the
first number in the spell scroll constructor's base reference:

   public EarthquakeScroll( int amount ) : base( 56, 0x1F65, amount )

You can see Earthquake would be m_SpellID = 56. and just set to the runes
you want Earthquake to require (doesn't HAVE to be what the scroll/spell
uses, but it's what your character will say so you decide =)  That's it,
new spell. :>


So Earthquake, continuing that example, would be:


// Earthquake: In Vas Por (Right?)
if ( ( foundIn && foundVas && foundPor ) && bag.Items.Count == 3 )
   m_SpellID = 56;


Only seven left to go! ;)



This magic system is friendly to changes to the core magic system,
just modify the spell as necessary in the core and then change the
runes used here for the appropriate spell entry.
You could also use alternate runes for the spells and leave it up
to the players to discover the combinations.



Suggestions:

This magic system is way overpowered. You could change the difficulty.
Right now the game thinks of them as 'scrolls' in terms of spell mana
cost and magery requirements, so changing that part will affect rune magic.

in spell.cs look for "circle -= 2"

change:
         if ( m_Scroll != null ) 
            circle -= 2; 

to:
         if ( m_Scroll != null && !(m_Scroll is RuneBag ) ) 
            circle -= 2; 


You could also customize it by adding checks below that, like:

	// to make them harder to cast and require more mana
         if ( m_Scroll is RuneBag ) 
            circle += 1; 



That's about it. =) Enjoy!