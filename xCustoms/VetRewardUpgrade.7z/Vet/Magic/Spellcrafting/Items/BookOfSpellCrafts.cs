#region AuthorHeader
//
//	SpellCrafting version 2.9, by Xanthos and TheOutkastDev
//
//  Based on original ideas and code by TheOutkastDev
//
#endregion AuthorHeader
using System;
using Server;
using Server.Targeting;
using Server.Mobiles;
using Server.SpellCrafting.Gumps;
using Server.SpellCrafting.Items;
using Server.SpellCrafting;
using Server.Commands;
using Server.Items;
using Server.Engines.VeteranRewards;

namespace Server.SpellCrafting.Items
{
    public class BookOfSpellCrafts : Item, IRewardItem
	{
        private bool m_IsRewardItem;
        [CommandProperty(AccessLevel.GameMaster)]
        public bool IsRewardItem
        {
            get { return m_IsRewardItem; }
            set { m_IsRewardItem = value; InvalidateProperties(); }
        }

		public static void Initialize()
		{
			CommandSystem.Register( "AllCrafts", AccessLevel.GameMaster, new CommandEventHandler( AllCrafts_OnCommand ) );
			CommandSystem.Register( "AddCraft", AccessLevel.GameMaster, new CommandEventHandler( AddCraft_OnCommand ) );
		}

		private static void AllCrafts_OnCommand( CommandEventArgs e )
		{
			e.Mobile.BeginTarget( -1, false, TargetFlags.None, new TargetCallback( AllCrafts_OnTarget ) );
			e.Mobile.SendMessage( "Select the book of spellcrafts to fill." );
		}

		[Usage( "AddCraft <num>" )]
		private static void AddCraft_OnCommand( CommandEventArgs e )
		{
			if ( e.GetInt32(0) < 0 || e.GetInt32(0) > SpellCraftConfig.LastAosCraftID )
			{
				e.Mobile.SendMessage( "Craft number must be between 0 and " + SpellCraftConfig.LastAosCraftID );
			}
			else
			{
				e.Mobile.BeginTarget( -1, false, TargetFlags.None, new TargetStateCallback( AddCraft_OnTarget ), e.GetInt32(0) );
				e.Mobile.SendMessage( "Select the book of spellcrafts to add this craft to." );
			}
		}

		private static void AllCrafts_OnTarget( Mobile from, object target )
		{
			if ( target is BookOfSpellCrafts )
			{
				BookOfSpellCrafts book = target as BookOfSpellCrafts;

				book.Content = ulong.MaxValue;

				from.SendMessage( "Book filled." );
			}
			else
			{
				from.SendMessage( "That is not a Book of Spellcrafts." );
			}
		}

		private static void AddCraft_OnTarget( Mobile from, object target, object state )
		{
			int num = (int)state;

			if ( target is BookOfSpellCrafts )
			{
				BookOfSpellCrafts book = target as BookOfSpellCrafts;

				if ( book.HasCraft( num ) )
				{
					from.SendMessage( "The book already has this craft." );
				}
				else
				{
					book.Content |= (ulong)1 << num;
					book.InvalidateProperties();
					from.SendMessage( "The spellcraft has been added to the book." );
				}
			}
			else
			{
				from.SendMessage( "That is not a Book of Spellcrafts." );
			}
		}

		private ulong m_Content;
		private int   m_Charges;

		public int Count
		{
			get { return GetCraftCount(); }
		}

		public ulong Content
		{
			get { return m_Content; }
			set { m_Content = value; }
		}

		public int Charges
		{
			get { return m_Charges; }
			set { m_Charges = value; InvalidateProperties(); }
		}

		[Constructable]
		public BookOfSpellCrafts() : base( 0x2254 )
		{
			Name = "Book of SpellCrafts";
			Hue = 0x461;
		}

		public BookOfSpellCrafts( Serial serial ) : base( serial )
		{
		}

		public override void AddNameProperties( ObjectPropertyList list )
		{
			base.AddNameProperties( list );
			list.Add( 1060662, "{0}\t{1} of {2}", "Crafts", Count, SpellCraftConfig.LastAosCraftID + 1 );

			if ( SpellCraftConfig.UseCharges )
				list.Add( 1060741, Charges.ToString() ); // charges: ~1_val~
		}


		public bool HasCraft( int CraftID )
		{
			return ( CraftID >= 0 && CraftID <= SpellCraftConfig.LastAosCraftID && (m_Content & ((ulong)1 << CraftID)) != 0 );
		}

		private int GetCraftCount()
		{
			int count = 0;

			for( int i = 0; i <= SpellCraftConfig.LastAosCraftID; ++i )
			{
				if ( HasCraft( i ) ) ++count;
			}

			return count;
		}

		public override void OnDoubleClick( Mobile from )
		{
            if (m_IsRewardItem && !RewardSystem.CheckIsUsableBy(from, this, null))
            {
                from.SendMessage("This does not belong to you!!");
                return;
            }
			if ( !IsChildOf( from.Backpack ) )
				from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.

			from.SendGump( new SpellCraftBook( from, this, 1 ) );
		}

		public override bool OnDragDrop( Mobile from, Item dropped )
		{
			if ( !IsChildOf( from.Backpack ) )
				from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.

			if ( dropped is BaseSpellCraft && dropped.Amount == 1 )
			{
				BaseSpellCraft craft = (BaseSpellCraft)dropped;

				if ( HasCraft( craft.CraftID ) )
				{
					from.SendMessage( "This spellcraft is already present in the book." );
					return false;
				}
				else
				{
					int val = craft.CraftID;

					if ( val >= 0 && val <= SpellCraftConfig.LastAosCraftID )
					{
						m_Content |= (ulong)1 << val;
						InvalidateProperties();
						craft.Delete();
						from.SendMessage( "The book accepts the craft." );
						return true;
					}
					return false;
				}
			}
			else if ( dropped is ArcaneGem )
			{
				m_Charges += dropped.Amount;
				InvalidateProperties();
				dropped.Delete();
				from.SendMessage( "The book accepts the magic jewels storing the energy in the book." );
				return true;
			}
			return false;
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();

			switch( version )
			{
					// version 0 reads second integer, version 1 no longer
					// needs it. No going to case 0 or serialization error
					// will occur!!
				case 2:
                    m_IsRewardItem = reader.ReadBool();
					m_Charges = reader.ReadInt();
					goto case 1;
				case 1:
					m_Content = reader.ReadULong(); break;
				case 0:
					m_Content = reader.ReadULong();
					int m_Count = reader.ReadInt(); break;
			}
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int)2 ); // version
            writer.Write((bool)m_IsRewardItem);
			writer.Write( m_Charges );
			writer.Write( m_Content );
		}
	}
}
