#region AuthorHeader
//
//	SpellCrafting version 2.9, by Xanthos and TheOutkastDev
//
//  Based on original ideas and code by TheOutkastDev
//
#endregion AuthorHeader
using System;
using Server;

namespace Server.SpellCrafting.Items
{
	public class AttackChanceJewel : BaseSpellCraft
	{
		[Constructable]
		public AttackChanceJewel() : this( 1 )
		{
                    Name = "Hit Chance Increase Craft";
		}

		[Constructable]
		public AttackChanceJewel( int amount ) : base( amount, 40 )
		{
		}

		public AttackChanceJewel( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt(); // version
		}
	}
}
