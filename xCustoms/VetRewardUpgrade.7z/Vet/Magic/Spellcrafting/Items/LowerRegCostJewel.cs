#region AuthorHeader
//
//	SpellCrafting version 2.9, by Xanthos and TheOutkastDev
//
//  Based on original ideas and code by TheOutkastDev
//
#endregion AuthorHeader
using System;
using Server;

namespace Server.SpellCrafting.Items
{
	public class LowerRegCostJewel : BaseSpellCraft
	{
		[Constructable]
		public LowerRegCostJewel() : this( 1 )
		{
  Name = "Lower Reagent Cost Craft";
		}

		[Constructable]
		public LowerRegCostJewel( int amount ) : base( amount, 17 )
		{
		}

		public LowerRegCostJewel( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt(); // version
		}
	}
}
