#region AuthorHeader
//
//	SpellCrafting version 2.9, by Xanthos and TheOutkastDev
//
//  Based on original ideas and code by TheOutkastDev
//
#endregion AuthorHeader
using System;
using Server;

namespace Server.SpellCrafting.Items
{
	public class BonusStamJewel : BaseSpellCraft
	{
		[Constructable]
		public BonusStamJewel() : this( 1 )
		{
  Name = "Stamina Bonus Craft";
		}

		[Constructable]
		public BonusStamJewel( int amount ) : base( amount, 4 )
		{
		}

		public BonusStamJewel( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt(); // version
		}
	}
}
