#region AuthorHeader
//
//	SpellCrafting version 2.9, by Xanthos and TheOutkastDev
//
//  Based on original ideas and code by TheOutkastDev
//
#endregion AuthorHeader
using System;
using Server;

namespace Server.SpellCrafting.Items
{
	public class LuckJewel : BaseSpellCraft
	{
		[Constructable]
		public LuckJewel() : this( 1 )
		{
  Name = "Luck Craft";
		}

		[Constructable]
		public LuckJewel( int amount ) : base( amount, 44 )
		{
		}

		public LuckJewel( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt(); // version
		}
	}
}
