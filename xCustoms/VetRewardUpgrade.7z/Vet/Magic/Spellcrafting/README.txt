//////////////////////////////////////////////
//Spellcrafting System v2.8					//
//Authors: Rewritten by Xanthos				//
//  based on original work by TheOutkastDev //
//											//
//////////////////////////////////////////////


What is it?

SpellCrafting is the ability to create magics that can be used to affix properties to an item.  The system uses two types of jewels, Spellcrafting Jewels and Magic Jewels.  The former provide for a specific property to be affixed to an item (i.e., faster casting).  The latter provide the charges that affix one of the Spellcrafting properties to an item. The server MUST be AOS ENABLED for this system to work.

- Namespaces:
Server.SpellCrafting;
Server.SpellCrafting.Crafts;
Server.SpellCrafting.Items;
Server.SpellCrafting.Mobiles;
Server.SpellCrafting.Gumps;


- Commands
[AddCraft <num> - adds the specified craft to the book.
[AllCrafts - adds all crafts to the specified book.
 

- Callbacks

All files contained in the Callbacks/ folder contain the target callback methods for each craft along with the minimum and maximum values that each prop can have. To adjust each property's min and max values, open up the selected file and find

	private static readonly int Minimum = <your value here>
	private static readonly int Maximum = <your value here>


- Items

+ Spellcraft Jewels

For each callback class there is an analogous Spellcraft Jewel class in the Items/ folder.  These jewels are added to Book of Spellcrafting, just like scrolls with a spellbook, by dropping them onto the book.  There are 50 different Spellcraft Jewels, each with a property that it can affix to items.

+ MagicJewel.cs

These jewels are used as charges when Spellcrafting and must reside in the player's back pack to affix a property onto an item.

+ BookOfSpellcrafts.cs

This is the craft book. Double click it to bring up a gump with an index of crafts that it contains.  The book is initially empty, as jewels are added, more properties become availble to affix to items.  Space in the book is limited.  A feature is implemented to allow players to see extra detail on the missing crafts in a book and the number of magic jewels consumed by each craft.  Holding a lit candle while opening the book allows this "hidden writing" to be displayed.


- Mobiles

+ GuardianOfTheMagics.cs

For those who like rp type addition of this system, this npc is a high hp caster that has a small chance to drop a random spellcraft and/or book. It always drops 3 Magic Jewels required to affix a property to an item.

+ SpellcraftVendor.cs 

For those who'd rather able to buy the spellcraft items, this vendor along w/ the sbinfo
 allows players to customize what is sold and bought.  By default all Spellcraft Jewels are on both the buy and sell lists.  Clicking on an individual Jewel in the vendor's list displays the property that it allows one to spellcraft.


- Gumps

+ SpellCraftBookGump.cs - this contains the gump and call outs to the methods for each craft.


- Other

+ Spellcraft.cs - the logic and data to apply the crafts as well as error handling text is maintained in this class.

+ Caveats - You are free to use or modify this code in any way you see fit.  I ask that you please leave all of the original headers intact if you redistribute this code in any way.  Thank you.


- Configuration

The file SpellCraftConfig.xml contains the methods that handle property application and other spellcraft methods. Important to note that at the top are 9 variables allowing easy configuration of the system:

+ MaxPropsAllowed - all items must have aos props totalling less than or equal to this  value. The default is 5, so if an item has 5 magic attributes, additional properties may not be spellcrafted onto it.  Existing properties may be modified with Spellcrafting however. **Armor Resistance Bonuses are excluded from this limitation**

+ ExplodeChance - the chance that the craft attempt will backfire and deal damage to the crafter.

+ DestroyChance - the chance that, during a backfire, the item that was trying to be crafted on will be destroyed.

+ ExplodeMinDmg - the minimum damage the backfire explosion does to the crafter.

+ ExplodeMaxDmg - the maximum damage the backfire explosion does to the crafter.

+ ArtifactCraftable - determines whether or not artifact items may be spellcrafted.

+ BaceletsRingsOnly - if true, of all the jewelry, only bracelets and rings may be spellcafted.

+ ScPenaltyChance - the chance that one will be subtracted from the fc of the item when spell channeling is applied to it.  FC will never go below -1.

+ MinimumInscription - minimum skill needed to use the book (default is 50).

+ MinimumAlchemy - minimum skill needed to use the book (default is 50).


+ bool[] Enabled - this array contains boolean values that determine whether or not a craft is enabled. If the craft is enabled, players can apply it to items and if it disabled, a message will inform the crafter that it has been disabled.


+ int [] MagicJewelRequirements - this array contains int values that determine how many magic jewels are consumed, for each craft, on spellcrafting attempts.


- The Craft/Item Table

The table below lists each of the crafts and the types of items they apply to.  Hats accept the same properties as armor.

Hit Chance Increase:		Shields	Weapons	Jewelry
Dexterity Bonus:				Jewelry
Hitpoint Bonus:		Armor			
Intelligence Bonus:				Jewelry
Mana Bonus:		Armor			
Stamina Bonus:		Armor			
Strength Bonus:					Jewelry
Cast Recovery:					Jewelry
Cast Speed:			Shields		Jewelry
Cold Resistance:	Armor	Shields	Weapons	Jewelry
Defense Chance Increase:	Shields	Weapons	Jewelry
Energy Resistance:	Armor	Shields	Weapons	Jewelry
Enhance Potions:				Jewelry
Fire Resistance:	Armor	Shields	Weapons	Jewelry
Hit Cold Area:				Weapons	
Hit Dispel:				Weapons	
Hit Energy Area:			Weapons	
Hit Fire Area:				Weapons	
Hit Fireball:				Weapons	
Hit Harm:				Weapons	
Hit Life Leech:				Weapons	
Hit Mana Leech:				Weapons	
Hit Stamina Leech:			Weapons	
Hit Lightning:				Weapons	
Hit Lower Attack:			Weapons	
Hit Lower Defense:			Weapons	
Hit Magic Arrow:			Weapons	
Hit Physical Area:			Weapons	
Hitpoint Regeneration:	Armor			
Hit Poison Area:			Weapons	
Lower Mana Cost:	Armor			Jewelry
Lower Reagent Cost:	Armor			Jewelry
Lower Requirements:	Armor	Shields	Weapons	
Luck:			Armor	Shields	Weapons	Jewelry
Mage Armor:		Armor			
Mage Weapon:				Weapons	
Mana Regeneration:	Armor			
Night Sight:		Armor	Shields		Jewelry	
Physical Resistance:	Armor	Shields	Weapons	Jewelry
Poison Resistance:	Armor	Shields	Weapons	Jewelry
Reflect Physical:	Armor	Shields		
Self Repair:		Armor	Shields		
Spell Channeling:		Shields	Weapons	
Spell Damage Increase:				Jewelry
Stamina Regeneration:	Armor			
Use Best Weapon Skill:			Weapons	
Weapon Damage Increase:			Weapons	Jewelry
Swing Speed Increase:			Weapons	
Night Sight:		Armor	Shields		Jewelry
Slayer:					Weapons		instruments
Durability:		Armor	Shields	Weapons