// the interface in this file has been moved to Interfaces.cs
// you can safely delete this file.

public interface I_Delete_This_File
{
	void Seriously();
}