using System;
using Server;
using Server.Engines.Craft;
using Server.Engines.VeteranRewards;

namespace Server.Items
{
    public class AncientMortarPestle : BaseTool, IRewardItem
	{
		public override CraftSystem CraftSystem{ get{ return DefLostAlchemy.CraftSystem; } }
        private bool m_IsRewardItem;
        [CommandProperty(AccessLevel.GameMaster)]
        public bool IsRewardItem
        {
            get { return m_IsRewardItem; }
            set { m_IsRewardItem = value; InvalidateProperties(); }
        }
		[Constructable]
		public AncientMortarPestle() : base( 0xE9B )
		{
			Weight = 1.0;
                        //Movable = false;
                        Hue = 0x387;
		}

		[Constructable]
		public AncientMortarPestle( int uses ) : base( uses, 0xE9B )
		{
			Weight = 10.0;
		}
        public override void OnDoubleClick(Mobile from)
        {
            if (m_IsRewardItem && !RewardSystem.CheckIsUsableBy(from, this, null))
            {
                from.SendMessage("This does not belong to you!!");
                return;
            }
            base.OnDoubleClick(from);
        }
		public AncientMortarPestle( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
            writer.Write((bool)m_IsRewardItem);
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
            m_IsRewardItem = reader.ReadBool();
		}
	}
}
