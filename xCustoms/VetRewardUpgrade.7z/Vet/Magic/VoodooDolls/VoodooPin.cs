using System;
using Server;
using Server.Network;
using Server.Targeting;
using Server.Mobiles;

namespace Server.Items
{
   public enum PinEffect
   {
      Harm,
      Cure,
      Heal,
      Poison
   }

   [FlipableAttribute( 0x1027, 0x1026 )]
   public class VoodooPin : Item
   {
      private bool m_Reusable;
      private PinEffect m_Effect;

      [CommandProperty( AccessLevel.GameMaster )]
      public PinEffect Effect
      {
         get   { return m_Effect; }
         set { m_Effect = value; }
      }

      [CommandProperty( AccessLevel.GameMaster )]
      public bool Reusable
      {
         get   { return m_Reusable; }
         set { m_Reusable = value; }
      }

      [Constructable]
      public VoodooPin() : base( 0x1027 )
      {
         Name = "a voodoo pin";
         Weight = 0.1;
         Hue = 0x397;
         Stackable = true;
         Reusable = false;
         Effect = PinEffect.Harm;
      }

      public override void OnDoubleClick( Mobile from )
      {
         if ( !Movable )
            return;
         from.Target = new InternalTarget( this );
      }

      public VoodooPin( Serial serial ) : base( serial )
      {
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );
         writer.Write( (int) 0 ); // version
         writer.Write( (int)m_Effect );
         writer.Write( m_Reusable );
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );
         int version = reader.ReadInt();
         m_Effect = ( PinEffect )reader.ReadInt();
         m_Reusable = reader.ReadBool();
      }

      public void Heal( Mobile from, Mobile target )
      {
         target.Heal( Utility.Random( 1, (int)(from.Skills[SkillName.Magery].Value / 4) ) );
         target.FixedParticles( 0x376A, 9, 32, 5030, EffectLayer.Waist );
         target.PlaySound( 0x202 );
      }

      public void Harm( Mobile from, Mobile target )
      {
         AOS.Damage( target, Utility.Random( 1, (int)(from.Skills[SkillName.Necromancy].Value / 4) ), 20, 20, 20, 20, 20 );
         target.FixedParticles( 0x374A, 10, 15, 5013, EffectLayer.Waist );
         target.PlaySound( 0x1F1 );
      }

      public void Cure( Mobile from, Mobile target )
      {
         target.CurePoison( from );
         target.FixedParticles( 0x373A, 10, 15, 5012, EffectLayer.Waist );
         target.PlaySound( 0x1E0 );
      }

      public void PoisonC( Mobile from, Mobile target )
      {
         target.ApplyPoison( from, Poison.GetPoison( Utility.Random(4) ) );
         target.FixedParticles( 0x374A, 10, 15, 5021, EffectLayer.Waist );
         target.PlaySound( 0x474 );
      }


      private class InternalTarget : Target
      {
         private VoodooPin Pin;

         public InternalTarget( VoodooPin pin ) : base( 1, false, TargetFlags.None )
         {
            Pin = pin;
         }

         protected override void OnTarget( Mobile from, object targeted )
         {
            if ( Pin.Deleted ) return;

            if ( targeted is VoodooDoll )
            {
               VoodooDoll v = (VoodooDoll)targeted;
               if( v.CursedPerson != null && (v.CursedPerson).Player && (v.CursedPerson).Alive )
               {
                  Mobile m = v.CursedPerson;

                  if ( m.NetState != null && from.CheckSkill( SkillName.Magery, 50, 100 ) && from.CheckSkill( SkillName.Necromancy, 50, 100 ) )
                  {
                     from.Karma = (from.Karma)-25;
                        from.SendLocalizedMessage( 1019063 ); // You have lost a little karma.
                     if( m.Female )
                     {
                        Effects.PlaySound( from.Location, from.Map, 0x326 );
                        Effects.PlaySound( m.Location, m.Map, 0x326 );
                     }
                     else
                     {
                        Effects.PlaySound( from.Location, from.Map, 0x437 );
                        Effects.PlaySound( m.Location, m.Map, 0x437 );
                     }
                     m.RevealingAction();
                     if ( m.Body.IsHuman && !m.Mounted )
                        m.Animate( 20, 5, 1, true, false, 0 );

                     if( Pin.Effect == PinEffect.Heal )
                     {
                        Pin.Heal( from, m );
                     }

                     if( Pin.Effect == PinEffect.Harm )
                     {
                        Pin.Harm( from, m );
                     }

                     if( Pin.Effect == PinEffect.Cure )
                     {
                        Pin.Cure( from, m );
                     }

                     if( Pin.Effect == PinEffect.Poison )
                     {
                        Pin.PoisonC( from, m );
                     }

                     if( !Pin.Reusable )
                        Pin.Consume();
                        from.SendMessage("The pin snapped");
                  }
                  else
                  {
                     from.SendMessage("The pin snapped");
                     Pin.Consume();
                  }
               }
               else
               {
                  from.SendMessage("You started poking the doll with the pin");
               }
            }
            else if( targeted is GreaterHealPotion )
            {
               Pin.Hue = 0x26;
               from.PlaySound( 0x240 );
               from.AddToBackpack( new Bottle() );
               ((BasePotion)targeted).Consume();
               if( from.CheckSkill( SkillName.Poisoning, 50, 100 ) )
                  Pin.Effect = PinEffect.Heal;
               else
                  from.SendMessage("You failed to apply the potion onto the pin");
            }
            else if( targeted is TotalRefreshPotion )
            {
               Pin.Hue = 0x397;
               from.PlaySound( 0x240 );
               from.AddToBackpack( new Bottle() );
               ((BasePotion)targeted).Consume();
               if( from.CheckSkill( SkillName.Poisoning, 50, 100 ) )
                  Pin.Effect = PinEffect.Harm;
               else
                  from.SendMessage("You failed to apply the potion onto the pin");
            }
            else if( targeted is GreaterCurePotion )
            {
               Pin.Hue = 0x37;
               from.PlaySound( 0x240 );
               from.AddToBackpack( new Bottle() );
               ((BasePotion)targeted).Consume();
               if( from.CheckSkill( SkillName.Poisoning, 50, 100 ) )
                  Pin.Effect = PinEffect.Cure;
               else
                  from.SendMessage("You failed to apply the potion onto the pin");
            }
            else if( targeted is GreaterPoisonPotion )
            {
               Pin.Hue = 0x47;
               from.PlaySound( 0x240 );
               from.AddToBackpack( new Bottle() );
               ((BasePotion)targeted).Consume();
               if( from.CheckSkill( SkillName.Poisoning, 50, 100 ) )
                  Pin.Effect = PinEffect.Poison;
               else
                  from.SendMessage("You failed to apply the potion onto the pin");
            }
            else
            {
               from.SendMessage("I don't think you can pin that");
            }
         }
      }
   }
}
