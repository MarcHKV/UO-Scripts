using System;
using Server;
using Server.Targeting;

namespace Server.Items
{
   [FlipableAttribute( 0x18DD, 0x18DE )]
   public class VoodooDoll : Item
   {
      private Mobile m_CursedPerson;

      [CommandProperty( AccessLevel.GameMaster )]
      public Mobile CursedPerson
      {
         get   { return m_CursedPerson; }
         set { m_CursedPerson = value; InvalidateProperties(); }
      }

      //[Constructable]
      public VoodooDoll( Mobile m ) : base( 0x18DD )
      {
         Name = "a voodoo doll";
         Weight = 3.0;
         Hue = 0x2D;
         Stackable = false;
         CursedPerson = m;
         InvalidateProperties();
      }

      public override void GetProperties( ObjectPropertyList list )
      {
         base.GetProperties( list );
         list.Add( "a voodoo doll of {0}", m_CursedPerson.Name  );
      }

      public override void OnSingleClick( Mobile from )
      {
         base.OnSingleClick( from );
         InvalidateProperties();
      }

      //[Constructable]
      public VoodooDoll() : this( null )
      {
      }

      public VoodooDoll( Serial serial ) : base( serial )
      {
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );
         writer.Write( (int) 0 ); // version
         writer.Write( m_CursedPerson );
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );
         int version = reader.ReadInt();
         m_CursedPerson = reader.ReadMobile();
      }
   }
   [FlipableAttribute( 0x18DD, 0x18DE )]
   public class Doll : Item
   {
      private Mobile m_CursedPerson;

      [CommandProperty( AccessLevel.GameMaster )]
      public Mobile CursedPerson
      {
         get   { return m_CursedPerson; }
         set { m_CursedPerson = value; }
      }

      [Constructable]
      public Doll() : base( 0x18DD )
      {
         Name = "a doll";
         Weight = 3.0;
         Hue = 0x3A3;
         Stackable = false;
      }

      public Doll( Serial serial ) : base( serial )
      {
      }

      public override void OnDoubleClick( Mobile from )
      {
         if ( !Movable )
            return;
         from.Target = new InternalTarget( this );
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );
         writer.Write( (int) 0 ); // version
         writer.Write( m_CursedPerson );
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );
         int version = reader.ReadInt();
         m_CursedPerson = reader.ReadMobile();
      }

      private class InternalTarget : Target
      {
         private Doll doll;

         public InternalTarget( Doll doll_ ) : base( 1, false, TargetFlags.None )
         {
            doll = doll_;
         }

         protected override void OnTarget( Mobile from, object targeted )
         {
            if ( doll.Deleted ) return;

            if ( targeted is Head && ((Head)targeted).Owner != null)
            {
               if( doll.CursedPerson == null )
               {
                  doll.CursedPerson = ((Head)targeted).Owner;
                  doll.Hue = 33;
                  doll.Name = "a blooded doll";
                  doll.InvalidateProperties();
                  ((Head)targeted).Consume();
                  from.SendMessage("You placed the head onto the doll");
                  from.Karma = (from.Karma)-25;
                  from.SendLocalizedMessage( 1019063 ); // You have lost a little karma.
               }
               else
                  from.SendMessage("There is already a head on the doll!");
            }
                 /*else
                 {
                  from.SendMessage("That is not a Players Head!");
                  }*/

                  
            if ( CookableFood.IsHeatSource( targeted ) )
            {
               if ( from.BeginAction( typeof( CookableFood ) ) )
               {
                  from.PlaySound( 0x225 );

                  doll.Consume();
                  InternalTimer t = new InternalTimer( from, targeted as IPoint3D, from.Map, doll );
                  t.Start();
               }
               else
               {
                  from.SendLocalizedMessage( 500119 ); // You must wait to perform another action
               }
            }
         }

         private class InternalTimer : Timer
         {
            private Mobile m_From;
            private IPoint3D m_Point;
            private Map m_Map;
            private Doll doll;

            public InternalTimer( Mobile from, IPoint3D p, Map map, Doll doll_ ) : base( TimeSpan.FromSeconds( 5.0 ) )
            {
               m_From = from;
               m_Point = p;
               m_Map = map;
               doll = doll_;
            }

            protected override void OnTick()
            {
               m_From.EndAction( typeof( CookableFood ) );

               //if ( m_From.Map != m_Map || (m_Point != null && m_From.GetDistanceToSqrt( m_Point ) > 3) )
               //{
                 // m_From.SendMessage("The doll ran away!");
                  //return;
               //}

               if ( m_From.CheckSkill( SkillName.Cooking, 90, 120 ) || m_From.CheckSkill( SkillName.Necromancy, 90, 120 ))
               {
                  m_From.SendMessage("You made a voodoo doll");
                  if ( m_From.AddToBackpack( new VoodooDoll(doll.CursedPerson) ) )
                     m_From.PlaySound( 0x57 );
               }
               else
               {
                  m_From.SendMessage("The doll screamed and ran around for awhile then turned into ash");
               }
            }
         }
      }
   }
}
