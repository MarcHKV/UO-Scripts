///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//			                         NPC Squire Script
//
//			Revesions:
//
//          	�shrink	
//						This version does away with the shrink system.  I found it to be difficult to impliment, since
//						it is designed to create and delete token items that represent the animal shrunk.  Instead,
//						clicking on the brace will now stable your squire, clicking again will unstable only the squire
//						for you.  If you Claim your squire from the stable master, it will automatically toggle
//						the brace for you, enabling stabling again.  This method needs to be tested with squires being
//						transfered.
//				
//				�Motive
//						I have added the command property Enum "motive" to the squire,  This expands upon the personality
//						properties, (added in the last release).  This will enable future expansions, an example of
//						what I intend to do with the script can be seen by using the "slave" command.  The squire will
//						respond based upon it's motive, personality, as well as existing attributes like sex.
//				
//				�Age
//						By request from roleplaying shards, the age attribute is not fully implimented in this release,
//						but could be used to modify responses (the young speak differently than the old), Stats and
//						Skill (an aged vetran might be more knowledgeable but have lower dexterity than a young squire)
//						Or even just details like graying hair.
//
//				�Binding
//						The Brace is now completly bound to the squire.  The Brace can set attributes on the squire,
//						and vise versa.
//
//				�Charges
//						There are recall, Gate and Attack Charges on the squire.  They can use Recall and gate scrolls
//						to gain charges.  They can remember a location with the "remember home" command.  "return home"
//						will teleport them to that location.  "summon moongate" will open a public moongate for 30 sec.
//						Attack Charges can be gained through combat, and are used to preform special moves.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using Server;
using Server.Items;
using Server.Gumps;
using Server.Network;
using Server.Targeting;
using Server.Spells;
using System.Reflection;
using Server.Mobiles;
//using Server.Scripts.Commands;
using System.Collections.Generic;
using Server.ContextMenus;
using Server.Regions;
using Server.Factions;
using Server.Misc;
using Server.Engines.VeteranRewards;

namespace Server.Mobiles
{
[CorpseName( "the remains of a young warrior" )]
public class Squire : BaseCreature
{

    private Point3D HouseLocation;
    private Map HouseMap;
    private int Recall_C;
    private int Gate_C;
    //private int Attack_C;
    public Item Bound;

    public enum SquirePersonality
    {
        Funny,
        Noble,
        Subserviant,
        Asshole,
        Defiant,
        PassiveAgressive,
        Arrogant,
        Cowardly
    }
    public SquirePersonality attitude;

    public enum SquireMotivation
    {
        Gold,
        Sex,
        Fame,
        Servitude,
        Honor,
        Quest1,
        Quest2,
        Quest3
    }
    public SquireMotivation motive;

    public enum SquireAge
    {
        Teenage,
        YoungAdult,
        MiddleAge,
        Old,
        Elder
    }
    public SquireAge age;

    [CommandProperty( AccessLevel.GameMaster )]
    public SquirePersonality Personality
    {
        get{return attitude;}
        set{attitude = value;}
    }
    [CommandProperty( AccessLevel.GameMaster )]
    public SquireMotivation Motivation
    {
        get{return motive;}
        set{motive = value;}
    }
    [CommandProperty( AccessLevel.GameMaster )]
    public SquireAge Age
    {
    	get{return age;}
    	set{age = value;}
    }

    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public Item BoundBrace
    {
        get{return Bound;}
        set{Bound = value;
            InvalidateProperties();}
    }

    /*[CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public int AttackCharges
    {
        get
        {
            return Attack_C;
        }
        set
        {
            Attack_C = value;
            InvalidateProperties();
        }
    }*/
    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public int RecallCharges
    {
        get
        {
            return Recall_C;
        }
        set
        {
            Recall_C = value;
            InvalidateProperties();
        }
    }
    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public int GateCharges
    {
        get
        {
            return Gate_C;
        }
        set
        {
            Gate_C = value;
            InvalidateProperties();
        }
    }

    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public Point3D HomeLocation
    {
        get
        {
            return HouseLocation;
        }
        set
        {
            HouseLocation = value;
            InvalidateProperties();
        }
    }

    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public Map HomeMap
    {
        get
        {
            return HouseMap;
        }
        set
        {
            HouseMap = value;
            InvalidateProperties();
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Construct Squire
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    [Constructable]
    public Squire(): base( AIType.AI_Vendor, FightMode.None, 10, 1, 0.2, 0.4 )
    {
        this.Personality = (SquirePersonality)(Utility.RandomMinMax(0,7));
        this.Motivation = (SquireMotivation)(Utility.RandomMinMax(0,4));
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Set Female Attributes
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        if ( this.Female == true )
        {


//Set Squire Type (Female)

            /*switch ( Utility.Random( 3 ) )
            {
//Mage
            case 0: this.Title = "the Shadow Priestess";
                AddItem( new Spellbook() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new Boots( Utility.RandomNeutralHue() ) );
                AddItem( new Robe( Utility.RandomNeutralHue() ) );
                AddItem( new WizardsHat( Utility.RandomNeutralHue() ) );
                //SetSkill( SkillName.Magery, 25.0, 35.0 );
                //SetSkill( SkillName.Meditation, 17.0, 25.0 );
                //SetSkill( SkillName.Tactics, 15.0 );
                //SetSkill( SkillName.EvalInt, 25.0 );
                SetSkill( SkillName.Mining, 25.0 );
                SetSkill( SkillName.Cooking, 35.0 );
                SetSkill( SkillName.Healing, 20.0 );
                this.AI = AIType.AI_None;
                break;
//Fighter
            case 1:*/ this.Title = "the Squire";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new Boots( Utility.RandomNeutralHue() ) );
                AddItem( new Cloak( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill(SkillName.Magery, 25.0, 35.0);
                SetSkill( SkillName.Mining, 25.0 );
                SetSkill( SkillName.Cooking, 35.0 );
                SetSkill( SkillName.Healing, 20.0 );
                SetSkill(SkillName.Swords, 25.0, 35.0);
                SetSkill(SkillName.Parry, 17.0, 25.0);
                SetSkill(SkillName.Tactics, 15.0);
                //this.AI = AIType.AI_None;
                //break;
//Theif
            /*case 2: this.Title = "the Rouge";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new ThighBoots( Utility.RandomNeutralHue() ) );
                AddItem( new HoodedShroudOfShadows( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill( SkillName.Swords, 25.0, 35.0 );
                SetSkill( SkillName.Parry, 17.0, 25.0 );
                SetSkill( SkillName.Tactics, 15.0 );
                SetSkill( SkillName.Hiding, 100.0 );
                SetSkill( SkillName.Stealing, 35.0 );
                SetSkill( SkillName.Stealth, 100.0 );
                this.AI = AIType.AI_Melee;
                break;*/
// Apprentice
            /*case 2: this.Title = "the Apprentice";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new ThighBoots( Utility.RandomNeutralHue() ) );
                AddItem( new FullApron( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill( SkillName.Swords, 25.0, 35.0 );
                SetSkill( SkillName.Healing, 17.0, 25.0 );
                SetSkill( SkillName.Camping, 15.0 );
                SetSkill( SkillName.Tailoring, 35.0 );
                SetSkill( SkillName.Mining, 35.0 );
                SetSkill( SkillName.Cooking, 35.0 );
                this.AI = AIType.AI_Melee;
                break;

            }*/

            SetResistance( ResistanceType.Physical, 65 );
            SetResistance( ResistanceType.Fire, 65 );
            SetResistance( ResistanceType.Poison, 100 );
            SetResistance( ResistanceType.Energy, 30 );
            SetResistance( ResistanceType.Cold, 60 );

            new Horse().Rider = this;
            ControlSlots = 2;
            ControlMaster = null;
            Container pack = Backpack;
            if ( pack != null )
                pack.Delete();
            pack = new StrongBackpack();
            pack.Movable = false;
            AddItem( pack );
            PackItem( new TentDeed() );
        }
        else

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Set Male Attributes
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        {

//Set Squire Type (Male)

            /*switch ( Utility.Random( 3 ) )
            {
//Mage
            case 0: this.Title = "the Shadow Priest";
                AddItem( new Spellbook() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new Boots( Utility.RandomNeutralHue() ) );
                AddItem( new Robe( Utility.RandomNeutralHue() ) );
                AddItem( new WizardsHat( Utility.RandomNeutralHue() ) );
                SetSkill( SkillName.Magery, 25.0, 35.0 );
                SetSkill( SkillName.Meditation, 17.0, 25.0 );
                SetSkill( SkillName.Tactics, 15.0 );
                SetSkill( SkillName.EvalInt, 25.0 );
                SetSkill( SkillName.Cooking, 35.0 );
                SetSkill( SkillName.Healing, 20.0 );
                this.AI = AIType.AI_Mage;
                break;
//Fighter
            case 1:*/ this.Title = "the Squire";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new Boots( Utility.RandomNeutralHue() ) );
                AddItem( new Cloak( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill(SkillName.Magery, 25.0, 35.0);
                SetSkill(SkillName.Mining, 25.0);
                SetSkill(SkillName.Cooking, 35.0);
                SetSkill(SkillName.Healing, 20.0);
                SetSkill(SkillName.Swords, 25.0, 35.0);
                SetSkill(SkillName.Parry, 17.0, 25.0);
                SetSkill(SkillName.Tactics, 15.0);
                //this.AI = AIType.AI_None;
                //break;
//Theif
            /*case 2: this.Title = "the Rouge";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new ThighBoots( Utility.RandomNeutralHue() ) );
                AddItem( new HoodedShroudOfShadows( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill( SkillName.Swords, 25.0, 35.0 );
                SetSkill( SkillName.Parry, 17.0, 25.0 );
                SetSkill( SkillName.Tactics, 15.0 );
                SetSkill( SkillName.Hiding, 100.0 );
                SetSkill( SkillName.Stealing, 35.0 );
                SetSkill( SkillName.Stealth, 100.0 );
                this.AI = AIType.AI_Melee;
                break;*/
// Apprentice
            /*case 2: this.Title = "the Apprentice";
                AddItem( new NeonWep() );
                AddItem( new LongPants( Utility.RandomNeutralHue() ) );
                AddItem( new FancyShirt( Utility.RandomNeutralHue() ) );
                AddItem( new ThighBoots( Utility.RandomNeutralHue() ) );
                AddItem( new FullApron( Utility.RandomNeutralHue() ) );
                AddItem( new BodySash( Utility.RandomNeutralHue() ) );
                SetSkill( SkillName.Swords, 25.0, 35.0 );
                SetSkill( SkillName.Healing, 17.0, 25.0 );
                SetSkill( SkillName.Camping, 15.0 );
                SetSkill( SkillName.Tailoring, 35.0 );
                SetSkill( SkillName.Mining, 35.0 );
                SetSkill( SkillName.Cooking, 35.0 );
                this.AI = AIType.AI_Melee;
                break;

            }*/

            SetResistance( ResistanceType.Physical, 65 );
            SetResistance( ResistanceType.Fire, 65 );
            SetResistance( ResistanceType.Poison, 100 );
            SetResistance( ResistanceType.Energy, 60 );
            SetResistance( ResistanceType.Cold, 30 );

			Item hair = new Item( Utility.RandomList( 0x203B, 0x2049, 0x2048, 0x204A ) );

			hair.Hue = Utility.RandomNondyedHue();
			hair.Layer = Layer.Hair;
			hair.Movable = false;

			AddItem( hair );
            new Horse().Rider = this;
            ControlSlots = 2;
            ControlMaster = null;
            Container pack = Backpack;
            if ( pack != null )
                pack.Delete();
            pack = new StrongBackpack();
            pack.Movable = false;
            AddItem( pack );
            PackItem( new TentDeed() );
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Set Immunities
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public override bool BardImmune{ get{ return false; } }
    //public override Poison PoisonImmune{ get{ return Poison.Deadly; } }
    public override bool CanRummageCorpses{ get{ return true; } }
    public override bool IsScaredOfScaryThings{ get{ return true; } }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Begin Speech Commands
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public override void OnSpeech( SpeechEventArgs e )
    {
        if (this.ControlMaster != null ){
            string addressmeas;
            string mastername;
            addressmeas = "Friend";
            mastername = "No One";
            if ( this.ControlMaster.Female == false && this.ControlMaster != null )
            {
                addressmeas = "Lord";
                mastername = this.ControlMaster.Name;
            }
            else if ( this.ControlMaster.Female == true && this.ControlMaster != null )
            {
                addressmeas = "Lady";
                mastername = this.ControlMaster.Name;
            }
            else if ( this.ControlMaster == null )
            {
                addressmeas = "Friend";
                mastername = "No One";
            }

            base.OnSpeech( e );
            Mobile from = e.Mobile;
            string message;
            if ( from.InRange( this, 4 )){
                if (this.ControlMaster != null && this.ControlMaster == from){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Reply to player
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    if (e.Speech.ToLower() == "slave" || e.Speech.ToLower() == "servant" || e.Speech.ToLower() == "squire")
                    {	message = " ";
                        if( this.Motivation == SquireMotivation.Gold )
                        {
                            if( this.Personality == SquirePersonality.Asshole)
                                message = "What do you want, and how much does the job pay?";
                            else if( this.Personality == SquirePersonality.Subserviant)
                                message = "How might I serve thee, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Noble)
                                message = "For gold and glory, I am at your command, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.PassiveAgressive)
                                message = "How might I help, " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Defiant)
                                message = addressmeas + " " + mastername + ", I have yet to see sufficant compensation for my service. Why should I answer you now?";
                            else if( this.Personality == SquirePersonality.Arrogant)
                                message = "What great deed dost thou wish of me, and at what price?";
                            else if( this.Personality == SquirePersonality.Cowardly)
                                message = "Yes, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Funny)
                                message = "Put some coins in my purse and I'll happily hear you out my friend.";
                            else
                                message = "Yes?";
                        }
                        else if( this.Motivation == SquireMotivation.Sex )
                        {
                            if( this.Personality == SquirePersonality.Asshole)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "What do you want now?";
                                    else
                                        message = "I'll serve you in battle when you serve me on your back or knees, My Lady.";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "You'd have me ride a smelly mount all day, when I'd sooner prefer to ride you My Lord.";
                                    else
                                        message = "What now? Shall I stable the horses for you while you whore with all the good men and leave me with the stable boy again?";
                                }
                            else if( this.Personality == SquirePersonality.Subserviant)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "Yes, My Lord.";
                                    else
                                        message = "How might I honor your beauty, My Lady";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "Anything for you, My Lord.";
                                    else
                                        message = "Yes, My Lady";
                                }
                            else if( this.Personality == SquirePersonality.Noble)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "How might I honor thee?";
                                    else
                                        message = "What can I do to win your favor, my Lady?";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "I serve only you, my Lord";
                                    else
                                        message = "How might I honor thee, my Lady?";
                                }
                            else if( this.Personality == SquirePersonality.PassiveAgressive)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "Your command is my purpose, Lord.";
                                    else
                                        message = "What ever My Lady wishes, I will see done.";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "Your command is my purpose, My Lord";
                                    else
                                        message = "What ever My Lord wishes, I will see done.";
                                }
                            else if( this.Personality == SquirePersonality.Defiant)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "Lord, women love a working man. I'd hate to win them all by doing everything for you.";
                                    else
                                        message = "Wench, why should I follow orders from a woman.";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "I work all day for you my Lord, let a tired girl rest a moment.";
                                    else
                                        message = "Your servant I may be, my lady.  But at least I have larger breasts than thee.";
                                }
                            else if( this.Personality == SquirePersonality.Arrogant)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "what?!  Oh, you want to know how I attract all the ladies, don't you my Lord?";
                                    else
                                        message = "I'll serve you well in battle, and better in bed, my Lady.";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "My Lord, I noticed you looking up my dress when I mounted my Horse.  Nice, isn't it?";
                                    else
                                        message = "Ok, one last order, then we can pick up a few knights at the pub and trun in early.";
                                }
                            else if( this.Personality == SquirePersonality.Cowardly)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "My Lord, I know it wrong for a man to say this to another man, but... I love thee, in the most sinful way.";
                                    else
                                        message = "My Lady?";
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        message = "You're so strong My lord.  Protect me, and I'll serve your every need.";
                                    else
                                        message = "Yes, my Lady?";
                                }
                            else if( this.Personality == SquirePersonality.Funny)
                                if (this.Female == false)
                                {
                                    if ( this.ControlMaster.Female == false )
                                        switch(Utility.Random(4)){
                                        case 0:{message = "Let's hurry up and be done with the work. There's a shepard's daughter in Yew I'd like to get back to.";};break;
                                        case 1:{message = "Sorry Lord, I was just day dreaming about that shepard's daughter again.";};break;
                                        case 2:{message = "Let's go find a damsel in distress.  I could use some good Hero Sex";};break;
                                        case 3:{message = "...that shepard's daughter. If she were a horse, I'd stick my wank in her flank and ride like the wind.";};break;}
                                    else
                                        switch(Utility.Random(4)){
                                        case 0:{message = "My Lady, I try to repress my feelings for you, but you make it hard... Literally.";};break;
                                        case 1:{message = "My Lady, If I should die in combat, I pray I can come back as your horse's saddle in the next life.";};break;
                                        case 2:{message = "Good morning My Lady, Your breasts look lovely today.";};break;
                                        case 3:{message = "Trust me not, My Lady. I'll defend your chastity with my long sword, all the while plotting to take it with my 'other sword'";};break;}
                                }
                                else
                                {
                                    if ( this.ControlMaster.Female == false )
                                        switch(Utility.Random(4)){
                                        case 0:{message = "I wrote you a poem.  Hail to my lord, with his giant sword. Parry and thrust to vanquish my lust...";};break;
                                        case 1:{message = "Lord, would you care for a backrub?";};break;
                                        case 2:{message = "Dost my Lord wish to fondle me again?";};break;
                                        case 3:{message = "My mount is tired.  Perhaps we could let it rest, and I'll ride your face instead, My Lord.";};break;}


                                    else
                                        switch(Utility.Random(4)){
                                        case 0:{message = "My Lady, we need to find some men.  It's been so long, even the livestock seems to tempt me.";};break;
                                        case 1:{message = "My lady, could we stop for a bath soon?  I don't know if that smell is comming from me or the horses.";};break;
                                        case 2:{message = "Remember that Knight we met in Serpant's Hold.  He could Lance me anytime.";};break;
                                        case 3:{message = "Let's join the savage camp, My lady.  Riding around with nothing but body paint on sounds exciting.";};break;}
                                }
                            else
                                message = "Yes?";
                        }
                        else
                        {
                            if( this.Personality == SquirePersonality.Asshole)
                                message = "What the hell do you want now?";
                            else if( this.Personality == SquirePersonality.Subserviant)
                                message = "How might I serve thee, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Noble)
                                message = "What noble task might I aid thee in, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.PassiveAgressive)
                                message = "How might I help, " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Defiant)
                                message = addressmeas + " " + mastername + ", Why dost thou assume I care to hear thy words?";
                            else if( this.Personality == SquirePersonality.Arrogant)
                                message = "What great deed dost thou wish of me?";
                            else if( this.Personality == SquirePersonality.Cowardly)
                                message = "Yes, My " + addressmeas + "?";
                            else if( this.Personality == SquirePersonality.Funny)
                                message = "Excuse me " + addressmeas + ", but my name is " + this.Name + ". Not Slave or Servant or Squire, but " + this.Name + ".";
                            else
                                message = "Yes?";
                        }

                        this.Say( message );
                        if (this.Female == true )
                            this.PlaySound( 799 );
                        else
                            this.PlaySound( 1071 );
                    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Tithe Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "tithe" || e.Speech.ToLower() == "donate")
                    {
                        from.SendGump( new TithingGump( from, 0 ) );
                        message = "I admire your faith.";
                        this.Say( message );
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Call
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "come here" || e.Speech.ToLower() == "return to me")
                    {
                        this.Map = this.BoundBrace.Map;
                        this.Location = this.BoundBrace.Location;
                        message = ("I am here, my " + addressmeas + ".");
                        this.Say( message );
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Bless Command    *** Causes Squire to stop responding to "All kill" command.  Stops Item Pick up
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//			else if (e.Speech.ToLower() == "i bless thee, squire")
//			{
//
//      			message = "I am honored by thy trust in me My " + addressmeas;
//        			this.Say( message );
//
//					if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 10000 ) )
//					{
//					this.Blessed = true;
//					}
//					else
//					{
//					message = ", but My " + addressmeas + ", the Gods require 10,000 Gold for this.";
//					this.Say( message );
//					}
//
//			}
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Curse Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//			else if (e.Speech.ToLower() == "i curse thee, squire")
//			{
//				message = "I shall endeavor to inspire your trust once again M'" + addressmeas + ".";
//      			this.Say( message );
//				this.Blessed = false;
//
//			}
//
//
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Hide/Show Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        else if (e.Speech.ToLower() == "squire show")
			{
        			message = "I am here Master.";
                                this.Say( message );
        			this.Hidden = false;
			}
                        else if (e.Speech.ToLower() == "squire hide")
			{
        			this.Hidden = true;
			}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Make Camp Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        /*else if (e.Speech.ToLower() == "new fire")
			{
                               IPooledEnumerable eable = this.Map.GetItemsInRange ( this.Location,  5 );
			        foreach ( Item item in eable )
			        {
                                     if ( item is BedRoll1 )
				        {
						Campfire camp = new Campfire(from) as Campfire;
                                                camp.X = this.X+5;
                                                camp.Y = this.Y;
                                                camp.Z = this.Z;
                                                camp.Map = this.Map;
                                                message = "I am securing thy camp now.";
			                        this.Say( message );
						eable.Free();
						return;
					}
				}

			}*/
			else if (e.Speech.ToLower() == "make camp" || e.Speech.ToLower() == "setup camp")
			{
                               if ( Validate(from) == false )
                               {
                               message = "Excuse me M'Lord but we can't set up here.";
			        this.Say( message );
                                //from.SendMessage( "We can't set up here." );
                                return;
                                }

                          if ( this.Backpack.ConsumeTotal( typeof( TentDeed ), 1 ))
		           {
                       Point3D fireLocation = GetFireLocation(this.ControlMaster);
                       new Campfire().MoveToWorld(fireLocation, from.Map);

               TentWalls v = new TentWalls();
               v.Location = from.Location;
               v.Map = from.Map;

               TentRoof w = new TentRoof();
               w.Location = from.Location;
               w.Map = from.Map;

               TentFloor y = new TentFloor();
               y.Location = from.Location;
               y.Map = from.Map;

               TentTrim z = new TentTrim();
               z.Location = from.Location;
               z.Map = from.Map;

               TentVerifier tentverifier = new TentVerifier();
               from.AddToBackpack (tentverifier);

               SecureTent chest = new SecureTent((PlayerMobile)from,v,w,y,z);
               chest.Location = new Point3D( from.X -1, from.Y-1, from.Z );
               chest.Map = from.Map;

               BedRoll1 x = new BedRoll1(v,w,y,z,(PlayerMobile)from, (SecureTent) chest,(TentVerifier) tentverifier);
               x.Location = new Point3D( from.X, from.Y+1, from.Z );
               x.Map = from.Map;
				message = "I am securing thy camp now.";
			        this.Say( message );
                }
                    else
		   {
		   from.SendMessage( "You must have the bedroll or its already set up somewhere." );
		   }
			}
                      else if (e.Speech.ToLower() == "remove camp" || e.Speech.ToLower() == "roll out")
			{
			foreach ( Item item in this.GetItemsInRange( 5 ) )
			{
                                if ( item is BedRoll1 )

	        {
         BedRoll1 BedRoll1 = (BedRoll1)item;
	   from.SendGump (new TentDGump(BedRoll1,from));
                }
         	}
			}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Remember Home
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "remember home")
                    {

                        this.HouseLocation = this.ControlMaster.Location;
                        this.HouseMap = this.ControlMaster.Map;
                        this.HomeLocation = this.ControlMaster.Location;
                        this.HomeMap = this.ControlMaster.Map;
                        this.Say("I shall remember this location.");
                    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Return Home
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "return home")
                    {
                        if (this.RecallCharges > 0)
                        {
                            this.Location = this.HomeLocation;
                            this.Map = this.HomeMap;
                            this.ControlOrder = OrderType.Stay;
                            this.Say("I am Home.");
                            this.RecallCharges -= 1;

                        }
                        else
                            this.Say("I need recall scrolls to do that.");
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Make Gate
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "summon moongate")
                    {
                        if (this.GateCharges > 0)
                        {
                            PublicMoongate newgate;
                            newgate = new PublicMoongate();
                            newgate.Map = this.Map;
                            newgate.Location = this.Location;
                            InternalTimer t = new InternalTimer( newgate );
                            t.Start();
                            Gate_C -= 1;
                        }
                        else
                            this.Say("I need Gate Travel scrolls to do that.");
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Who Is Master Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "master" || e.Speech.ToLower() == "who's your daddy")
                    {
                        message = "I am a desciple of " + addressmeas + " " + mastername;
                        this.Say( message );
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Dismount Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "squire dismount" && this.ControlMaster == from)
                    {
                        if (this.Mount != null)
                        {
                            message = "As you command.";
                            IMount mount = this.Mount;
                            if ( mount != null )
                                mount.Rider = null;

                            if ( mount is Mobile )
                                ((Mobile)mount).Delete();
                            this.Say( message );
                        }
                        else
                        {
                            message = "But I'm not on a mount.";
                            this.Say( message );
                        }
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Remount Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Horse
                    else if (e.Speech.ToLower() == "squire remount horse")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 900 ) || this.Backpack != null && this.Backpack.ConsumeTotal( typeof( Gold ), 900 ) )
                        {
                            new Horse().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "But we haven't the 900 Gold to buy this mount.";
                            this.Say( message );
                        }
                    }
//Ostard
                    else if (e.Speech.ToLower() == "squire remount ostard")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 1000 ) )
                        {
                            new ForestOstard().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "But we haven't the 1,000 Gold to buy this mount.";
                            this.Say( message );
                        }
                    }
//Swampdragon
                    else if (e.Speech.ToLower() == "squire remount swampdragon")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Fame >= 50000 )
                        {
                            new SwampDragon().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I need more fame to ride such a creature.";
                            this.Say( message );
                        }
                    }


//Swampdragon (barded)
                    else if (e.Speech.ToLower() == "squire remount barded swampdragon")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Fame >= 10000 )
                        {
                            new ScaledSwampDragon().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I need more fame to ride such a creature.";
                            this.Say( message );
                        }
                    }
//Llama
                    else if (e.Speech.ToLower() == "squire remount llama")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 2000 ) )
                        {
                            new RidableLlama().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "But we haven't the 2,000 Gold to buy this mount.";
                            this.Say( message );
                        }
                    }
//Ridgeback
                    else if (e.Speech.ToLower() == "squire remount ridgeback")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Fame >= 1000 )
                        {
                            new Ridgeback().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I need more fame to ride such a creature.";
                            this.Say( message );
                        }
                    }
//Skeletal Mount
                    else if (e.Speech.ToLower() == "squire remount skeletal horse")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Fame >= 10000 )
                        {
                            new SkeletalMount().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I need more fame to ride such a creature.";
                            this.Say( message );
                        }
                    }
//FireSteed
                    else if (e.Speech.ToLower() == "squire remount fire steed")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Fame >= 10000 )
                        {
                            new FireSteed().Rider = this;
                            message = "As you command.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I need more fame to ride such a creature.";
                            this.Say( message );
                        }
                    }
//Unicorn
                    else if (e.Speech.ToLower() == "squire remount unicorn")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if ( this.Female == true )
                        {
                            if ( this.Fame >= 10000 )
                            {
                                new Unicorn().Rider = this;
                                message = "As you command.";
                                this.Say( message );
                            }
                            else
                            {
                                message = "I need more fame to ride such a creature.";
                                this.Say( message );
                            }
                        }
                        else
                        {
                            message = "Sire, I don't believe Unicorns will allow a man to ride them.";
                            this.Say( message );
                        }
                    }
//NightMare
                    else if (e.Speech.ToLower() == "squire remount nightmare")
                    {
                        if (this.Mount != null)
                        {
                            message = "I am already mounted.";
                            this.Say( message );
                            return;
                        }
                        if (0 >= this.ControlMaster.Karma)
                        {
                            if ( this.Fame >= 10000 )
                            {
                                new Nightmare().Rider = this;
                                message = "As you command.";
                                this.Say( message );
                            }
                            else
                            {
                                message = "I need more fame to ride such a creature.";
                                this.Say( message );
                            }
                        }
                        else
                        {
                            message = addressmeas + ", I don't think virtous people should ride these beasts.";
                            this.Say( message );
                        }
                    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Disrobe Command
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "squire disrobe" && this.ControlMaster == from)
                    {
                        if ( this.Female && !from.Female )
                            message = "Sir, I am your loyal Squire, not a whore.  I'll do as you command, but HANDS OFF.";
                        else if ( !this.Female && !from.Female)
                            message = "Turn around my Lord. It's not right for men to do this in front of one another.";
                        else if ( this.Female && from.Female)
                            message = "But my Lady, this is quite undignified.";
                        else if ( !this.Female && from.Female)
                            message = "You show me your's, and I'll show you mine, M'Lady.";
                        else
                            message = " ";

                        Container pack = this.Backpack;
                        ArrayList equipitems = new ArrayList(this.Items);
                        foreach (Item item in equipitems)
                        {
                            if (item.Movable != false)
                            {
                                if ((item.Layer != Layer.Bank) && (item.Layer != Layer.Backpack) && (item.Layer != Layer.Hair) && (item.Layer != Layer.FacialHair) && (item.Layer != Layer.Mount) && (item.Layer != Layer.OneHanded))
                                {
                                    pack.DropItem( item );
                                }
                            }
                        }
                        this.Say( message );
                    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Disarm Command
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "squire disarm" && this.ControlMaster == from)
                    {
                        message = "Yes, My " + addressmeas;

                        Container pack = this.Backpack;
                        ArrayList equipitems = new ArrayList(this.Items);
                        foreach (Item item in equipitems)
                        {
                            if (item.Movable != false)
                            {
                                if (item.Layer == Layer.OneHanded || item.Layer == Layer.TwoHanded)
                                {
                                    pack.DropItem( item );
                                }
                            }
                        }
                        this.Say( message );
                    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Play me a song
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "play me a song")
                    {
                        this.PlaySound( 1035 );
                    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Herald
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    else if (e.Speech.ToLower() == "herald my coming" && this.ControlMaster == from)
                    {
                        PlayerMobile pm = this.ControlMaster as PlayerMobile;
                        string customTitle = pm.Title;
                        PlayerState pl = PlayerState.Find(pm);
                        RankDefinition[] rank = pl.Faction.Definition.Ranks;
                        this.PlaySound( 747 );
                        this.Say( "Ladies and Gentlemen, It is my distinguished honor to introduce my master " + addressmeas + " " + mastername + ".");
                        if (customTitle != null && (customTitle = customTitle.Trim()).Length > 0)
                        {
                            this.Say(customTitle + ".");
                        }
                        /*if (pm.CityTitle != null)
                        {
                            this.Say("With the current status of " + pm.CityTitle + ".");
                        }
                        if (pm.City != null)
                        {
                            this.Say("Residing from the" + pm.City + "."); 
                        }*/
                        if (pl.Faction != null)
                        {
                            this.Say(addressmeas + " " + mastername + "will fight to the Death fighting for " + pl.Faction + ".");
                        }
                        if (rank != null)
                        {
                            this.Say("and has a Rank of " + rank + " .");
                        }
                        if (this.ControlMaster.Guild != null)
                        {
                            this.Say("also a Proud" + pm.GuildRank.Name + "of " + this.ControlMaster.Guild + ".");
                        }
                        if (this.ControlMaster.GuildTitle != null)
                        {
                            this.Say("affectionately known as " + this.ControlMaster.GuildTitle + " to his Guild Mates.");
                        }
                        if (this.Personality == SquirePersonality.Asshole)
                            this.Say("*whispers* Yes He makes Me say all that.");
                        else if (this.Personality == SquirePersonality.Subserviant)
                            this.Say("My " + addressmeas + "is so wonderful.");
                        else if (this.Personality == SquirePersonality.Noble)
                            this.Say("I surely strive to be as Noble");
                        else if (this.Personality == SquirePersonality.PassiveAgressive)
                            this.Say("Thats is all.");
                        else if (this.Personality == SquirePersonality.Defiant)
                            this.Say("Next time You announce Me.");
                        else if (this.Personality == SquirePersonality.Arrogant)
                            this.Say("and I thought I was arrogant.");
                        else if (this.Personality == SquirePersonality.Cowardly)
                            this.Say("As My Lord Commands.");
                        else if (this.Personality == SquirePersonality.Funny)
                            if (this.Female == false)
                            {
                                if (this.ControlMaster.Female == false)
                                    this.Say(".");
                                else
                                    this.Say(".");
                            }
                    }
                    else if (e.Speech.ToLower() == "heal me" && this.ControlMaster == from)
                    {
                        if (this.Backpack != null && this.Backpack.ConsumeTotal( typeof( Bandage ), 1 ) || from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Bandage ), 1 ))
                        {

                            if ((this.Skills[SkillName.Healing].Base / 100 ) >= Utility.RandomDouble())
                            {
                                if ((int)(((from.RawStr / 2) + 50) * (this.Skills[SkillName.Healing].Base / 100)) >= from.Hits)
                                    this.ControlMaster.Hits = (int)(((this.ControlMaster.RawStr / 2) + 50) * (this.Skills[SkillName.Healing].Base / 100));
                                else
                                    this.Say( "Stop being such a wimp.  You only have a few minor scratchs.");
                                if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Healing].Base < 100 )
                                {
                                    this.Skills[SkillName.Healing].Base = this.Skills[SkillName.Healing].Base + 0.1;
                                    this.Say( "My Medical Knowledge has increased to, " );
                                    this.Say( this.Skills[SkillName.Healing].Base.ToString() );
                                }
                            }
                            else
                            {
                                if (this.Backpack != null && this.Backpack.ConsumeTotal( typeof( Bandage ), 1 ) || from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Bandage ), 1 ))
                                {
                                    message = "I am afraid my skill was insufficiant to heal your wounds, My " + addressmeas;
                                    this.Say( message );
                                }
                            }
                        }
                        else
                            this.Say( "We have no more Bandages!" );
                    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Food Preperation Command
////////////////////////////////////////////////////////////////////////////////////////////////
                    else if (e.Speech.ToLower() == "food" || e.Speech.ToLower() == "cook" || e.Speech.ToLower() == "dinner")
                    {
                        if ((this.Skills[SkillName.Cooking].Base / 100) >= Utility.RandomDouble() )
                        {
                            int c = 0;
//Ribs
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawRibs ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new Ribs( 1 ));
                                    c = ( c + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( RawRibs ), 1 ));

                                message = "Not even Kings have tasted Ribs as tender as these.";
                                this.Say( message );

                                if ( 0.5 >= Utility.RandomDouble() && this.Skills[SkillName.Cooking].Base < 100 )
                                {
                                    this.Skills[SkillName.Cooking].Base = this.Skills[SkillName.Cooking].Base + 1;
                                    message = "My Skill as a chef has improved.";
                                    this.Say( message );
                                }
                                c= 0;
                            }
//Lamb
                            else if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawLambLeg ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new LambLeg( 1 ));
                                    c = ( c + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( RawLambLeg ), 1 ));

                                message = "Smoked Lamb, This Dish is My Specialty.  Enjoy Sir.";
                                this.Say( message );

                                if ( 0.5 >= Utility.RandomDouble() && this.Skills[SkillName.Cooking].Base < 100 )
                                {
                                    this.Skills[SkillName.Cooking].Base = this.Skills[SkillName.Cooking].Base + 1;
                                    message = "My Skill as a chef has improved.";
                                    this.Say( message );
                                }
                                c= 0;
                            }
//Fish
                            else if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawFishSteak ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new FishSteak( 1 ));
                                    c = ( c + 1 );

                                }
                                while( from.Backpack.ConsumeTotal( typeof( RawFishSteak ), 1 ));

                                message = "I detest the stench of fish.  Next time cook it your self.";
                                this.Say( message );

                                if ( 0.5 >= Utility.RandomDouble() && this.Skills[SkillName.Cooking].Base < 100 )
                                {
                                    this.Skills[SkillName.Cooking].Base = this.Skills[SkillName.Cooking].Base + 1;
                                    message = "My Skill as a chef has improved.";
                                    this.Say( message );
                                }
                                c= 0;
                            }
//Poultry
                            else if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawBird ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new CookedBird( 1 ));
                                    c = ( c + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( RawBird ), 1 ));

                                message = "Why is it that I do all the cooking, and you do all the eating. I'm Hungry too.";
                                this.Say( message );

                                if ( 0.5 >= Utility.RandomDouble() && this.Skills[SkillName.Cooking].Base < 100 )
                                {
                                    this.Skills[SkillName.Cooking].Base = this.Skills[SkillName.Cooking].Base + 1;
                                    message = "My Skill as a chef has improved.";
                                    this.Say( message );
                                }
                                c= 0;
                            }
                            else
                            {
                                message = "But we have no meat to cook, Lord.";
                                this.Say( message );
                            }
                        }
                        else
                        {
                            message = "I am sorry, My " + addressmeas + ". But I'm afraid the food has burnt.";
                            this.Say( message );
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawBird ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawFishSteak ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawLambLeg ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( RawRibs ), 10 )){}
                        }
                    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Buy Reagents
////////////////////////////////////////////////////////////////////////////////////////////////
                    else if (e.Speech.ToLower() == "squire regs" || e.Speech.ToLower() == "squire buy reagents")
                    {
                        if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 1000 ) )
                        {
                            from.AddToBackpack( new BagOfReagents( 75 ));
                            message = "Your total comes to 1000gp.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I'm sorry my " + addressmeas + ", but you haven't the 1000gp for that";
                            this.Say( message );
                        }
                    }
                    else if (e.Speech.ToLower() == "squire necro regs" || e.Speech.ToLower() == "squire buy necro reagents")
                    {
                        if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( Gold ), 1000 ) )
                        {
                            from.AddToBackpack( new BagOfNecroReagents( 75 ));
                            message = "Your total comes to 1000gp.";
                            this.Say( message );
                        }
                        else
                        {
                            message = "I'm sorry my " + addressmeas + ", but you haven't the 1000gp for that";
                            this.Say( message );
                        }
                    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Resurrect
////////////////////////////////////////////////////////////////////////////////////////////////
                    else if (e.Speech.ToLower() == "res" || e.Speech.ToLower() == "resurrect")
                    {
                        if ( !from.Alive )
                        {
                            if (this.Skills[SkillName.Healing].Base >= 80.0)
                            {
                                Resurrect( from );
                                this.Say("I shall summon thee back from the abyss, my " + addressmeas);
                            }
                            else
                                this.Say("Be gone you dreadful spirit. I have not the skill to bring thee back.");
                        }
                        else
                            this.Say(addressmeas + ", You are very much alive already.");
                    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Post Skill Levels
////////////////////////////////////////////////////////////////////////////////////////////////
                    //Swords
                    else if (e.Speech.ToLower() == "sword skill")
                    {
                        message = this.Skills[SkillName.Swords].Base.ToString();
                        this.Say( "My Present Swordsmanship Skill Is, " );
                        this.Say( message );
                    }
                    //Healing
                    else if (e.Speech.ToLower() == "healing skill")
                    {
                        message = this.Skills[SkillName.Healing].Base.ToString();
                        this.Say( "My Present Healing Skill Is, " );
                        this.Say( message );
                    }
                    //Cooking
                    else if (e.Speech.ToLower() == "cooking skill")
                    {
                        message = this.Skills[SkillName.Cooking].Base.ToString();
                        this.Say( "My Present Cooking Skill Is, " );
                        this.Say( message );
                    }
                    //Tactics
                    else if (e.Speech.ToLower() == "tactic skill")
                    {
                        message = this.Skills[SkillName.Tactics].Base.ToString();
                        this.Say( "My Present Tactics Skill Is, " );
                        this.Say( message );
                    }
                    //Parry
                    else if (e.Speech.ToLower() == "parry skill")
                    {
                        message = this.Skills[SkillName.Parry].Base.ToString();
                        this.Say( "My Present Parrying Skill Is, " );
                        this.Say( message );
                    }
                    //Mining
                    else if (e.Speech.ToLower() == "mining skill")
                    {
                        message = this.Skills[SkillName.Mining].Base.ToString();
                        this.Say( "My Present Mining Skill Is, " );
                        this.Say( message );
                    }
                    //Magery
                    else if (e.Speech.ToLower() == "mage skill")
                    {
                        message = this.Skills[SkillName.Magery].Base.ToString();
                        this.Say( "My Present Magery Skill Is, " );
                        this.Say( message );
                    }
                    //Meditation
                    else if (e.Speech.ToLower() == "meditation skill")
                    {
                        message = this.Skills[SkillName.Meditation].Base.ToString();
                        this.Say( "My Present Meditation Skill Is, " );
                        this.Say( message );
                    }
                    //Stealing
                    else if (e.Speech.ToLower() == "stealing skill")
                    {
                        message = this.Skills[SkillName.Stealing].Base.ToString();
                        this.Say( "My Present Stealing Skill Is, " );
                        this.Say( message );
                    }
                    //Fencing
                    else if (e.Speech.ToLower() == "fencing skill")
                    {
                        message = this.Skills[SkillName.Fencing].Base.ToString();
                        this.Say( "My Present Fencing Skill Is, " );
                        this.Say( message );
                    }
                    //Wrestling
                    else if (e.Speech.ToLower() == "wrestling skill")
                    {
                        message = this.Skills[SkillName.Wrestling].Base.ToString();
                        this.Say( "My Present Wrestling Skill Is, " );
                        this.Say( message );
                    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Mage Special Skill
////////////////////////////////////////////////////////////////////////////////////////////////
                   /* else if (e.Speech.ToLower() == "mactabilis") // Latin for Leathal or Deadly
                    {
                        if ( this.AI == AIType.AI_Mage && this.AttackCharges > 0 )
                        {
                            MegaSpell(this.ControlMaster);
                            this.Say("Our minds shall act as one, my " + addressmeas + ".");
                            this.AttackCharges -= 1;

                        }
                        else if (this.AI != AIType.AI_Mage)
                        {
                            this.Say("But my " + addressmeas + ", I am no mage.");
                        }
                        else
                        {
                            this.Say("I haven't the attack charges to do that.");
                        }
                    }*/
////////////////////////////////////////////////////////////////////////////////////////////////
//  Smelt Ore
////////////////////////////////////////////////////////////////////////////////////////////////
                    else if (e.Speech.ToLower() == "smelt")
                    {

                        if ((this.Skills[SkillName.Mining].Base / 100) >= Utility.RandomDouble() )
                        {
                            int i = 0;
                            //Iron
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( IronOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new IronIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( IronOre ), 1 ));
                            }
                            i = 0;
                            //DullCopper
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( DullCopperOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new DullCopperIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( DullCopperOre ), 1 ));
                            }
                            i = 0;
                            //ShadowIron
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( ShadowIronOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new ShadowIronIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( ShadowIronOre ), 1 ));
                            }
                            i = 0;
                            //Copper
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( CopperOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new CopperIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( CopperOre ), 1 ));
                            }
                            i = 0;
                            //Bronze
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( BronzeOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new BronzeIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( BronzeOre ), 1 ));
                            }
                            i = 0;
                            //Gold
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( GoldOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new GoldIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( GoldOre ), 1 ));
                            }
                            i = 0;
                            //Agapite
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( AgapiteOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new AgapiteIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( AgapiteOre ), 1 ));
                            }
                            i = 0;
                            //Verite
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( VeriteOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new VeriteIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( VeriteOre ), 1 ));
                            }
                            i = 0;
                            //Valorite
                            if ( from.Backpack != null && from.Backpack.ConsumeTotal( typeof( ValoriteOre ), 1 ) )
                            {
                                do
                                {
                                    from.AddToBackpack( new ValoriteIngot( 2 ));
                                    i = ( i + 1 );
                                }
                                while( from.Backpack.ConsumeTotal( typeof( ValoriteOre ), 1 ));
                            }
                            i = 0;

                            message = "I have smelted your ore, My Lord.";
                            this.Say( message );
                            if ( 0.5 >= Utility.RandomDouble() && this.Skills[SkillName.Mining].Base < 100 )
                            {
                                this.Skills[SkillName.Mining].Base = this.Skills[SkillName.Mining].Base + 1;
                                message = "I Have Gained Skill In Mining.";
                                this.Say( message );
                            }

                            if ( 0.2 >= Utility.RandomDouble() && this.RawStr < 100 )
                            {
                                this.RawStr = this.RawStr + 1;
                                message = "I am Stronger Now!";
                                this.Say( message );
                            }


                            // To add custom ore types just copy the above ^^^
                        }
                        else
                        {
                            message = "I Applolgize my Lord, but I was unable to smelt the ore.";
                            this.Say( message );
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( ValoriteOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( VeriteOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( AgapiteOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( BronzeOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( CopperOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( DullCopperOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( ShadowIronOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( GoldOre ), 10 )){}
                            if (from.Backpack != null && from.Backpack.ConsumeTotal( typeof( IronOre ), 10 )){}
                        }
                    }

                }
            }}}
////////////////////////////////////////////////////////////////////////////////////////////////
//  Ressurect Method
////////////////////////////////////////////////////////////////////////////////////////////////
    public static void Resurrect( Mobile m )
    {
        if ( m.Alive )
            return;
        else
        {
            m.SendGump( new ResurrectGump( m, ResurrectMessage.VirtueShrine ) );
            m.RawDex = m.RawDex - 2;
            m.RawStr = m.RawStr - 2;
            m.RawInt = m.RawInt - 2;
            m.Fame -= 1000;
            m.Hits = m.RawStr / 3;
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Melee Attack
////////////////////////////////////////////////////////////////////////////////////////////////
    /*public override void OnGaveMeleeAttack( Mobile defender )
    {
        if ( this.Combatant.Hits < this.DamageMin )
            this.AttackCharges += Utility.RandomMinMax( 1, 5 );
///////////////////////////////////////////////////////////////////////////////////////////////
//  Squire Fame (10% chance of adding 10% Target fame to yours. (squire Special Move)
///////////////////////////////////////////////////////////////////////////////////////////////
		if (this.AI == AIType.AI_Melee && Utility.RandomMinMax( 1, 100 ) < 10)
		    {
		    if (this.AttackCharges > 0 && this.ControlMaster.Fame < 50000 && this.Combatant.Hits < this.DamageMin )
		   		{
		    	this.ControlMaster.Fame = this.ControlMaster.Fame + (int)(Math.Floor(defender.Fame / 10));
		    	this.Say("You have gained fame.");
		    	this.AttackCharges = this.AttackCharges - 1;
		    	}
		    }
        // Get Fame
        if ( 0.3 >= Utility.RandomDouble())
           this.Fame = this.Fame + (this.Combatant.RawStr / 10 );
        // Melee Attack Skill Gain
        if ( this.AI == AIType.AI_Melee )
        {
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Swords].Base < 100 && this.AI == AIType.AI_Melee)
            {
                this.Skills[SkillName.Swords].Base = this.Skills[SkillName.Swords].Base + 0.1;
                this.Say( "My skill with a sword has increased to, " );
                this.Say( this.Skills[SkillName.Swords].Base.ToString() );
            }
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Tactics].Base < 100 )
            {
                this.Skills[SkillName.Tactics].Base = this.Skills[SkillName.Tactics].Base + 0.1;
                this.Say( "My Tactical combat ability increased to, " );
                this.Say( this.Skills[SkillName.Tactics].Base.ToString() );
            }
        }
        //Mage Melee Skill Gain
        else if (this.AI == AIType.AI_Mage)
        {
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Wrestling].Base < 100 )
            {
                this.Skills[SkillName.Wrestling].Base = this.Skills[SkillName.Wrestling].Base + 0.1;
                this.Say( "My wrestling skill has increased to, " );
                this.Say( this.Skills[SkillName.Wrestling].Base.ToString() );
            }
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.EvalInt].Base < 100 )
            {
                this.Skills[SkillName.EvalInt].Base = this.Skills[SkillName.EvalInt].Base + 0.1;
                this.Say( "My Evaluating Intellegence skill increased to, " );
                this.Say( this.Skills[SkillName.EvalInt].Base.ToString() );
            }

        }

        else if (this.AI == AIType.AI_Thief)
        {
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Swords].Base < 100 )
            {
                this.Skills[SkillName.Swords].Base = this.Skills[SkillName.Swords].Base + 0.1;
                this.Say( "My swords skill has increased to, " );
                this.Say( this.Skills[SkillName.Fencing].Base.ToString() );
            }
            if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Tactics].Base < 100 )
            {
                this.Skills[SkillName.Tactics].Base = this.Skills[SkillName.Tactics].Base + 0.1;
                this.Say( "My Tactical combat ability increased to, " + this.Skills[SkillName.Tactics].Base.ToString() );
                //this.Say( this.Skills[SkillName.Tactics].Base.ToString() );
            }
        }      
////////////////////////////////////////////////////////////////////////////////////////////////
//  Disarm Attacker (Theif)
////////////////////////////////////////////////////////////////////////////////////////////////
        if (this.AI == AIType.AI_Thief && 0.2 >= Utility.RandomDouble())
        {
            Container pack = defender.Backpack;
            ArrayList dropitems = new ArrayList(defender.Items);
            foreach (Item item in dropitems)
            {
                if (item.Movable != false)
                {
                    if (item.Layer == Layer.OneHanded || item.Layer == Layer.TwoHanded)
                    {
                        pack.DropItem( item );
                        //defender.Stam = defender.Stam - /*(int)(Math.Floor( defender.Stam / 2 ));
                        this.Say("I have Disarmed my opponent.");
                    }
                }
            }
        }

    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Melee Defend
////////////////////////////////////////////////////////////////////////////////////////////////
    /*public override void OnGotMeleeAttack( Mobile attacker )
    {
        if ( 0.1 >= Utility.RandomDouble() && this.Skills[SkillName.Parry].Base < 100 )
        {
            this.Skills[SkillName.Parry].Base = this.Skills[SkillName.Parry].Base + 0.1;
            this.Say( "My evasive skill has increased to, " );
            this.Say( this.Skills[SkillName.Parry].Base.ToString() );
        }

    }*/
    public bool Validate(Mobile from)
	  {
	         if(from.Region.Name != "Cove" && from.Region.Name != "Britain" &&//towns
                   from.Region.Name != "Jhelom" && from.Region.Name != "Minoc" &&//towns
                   from.Region.Name != "Haven" && from.Region.Name != "Trinsic" &&//towns
                   from.Region.Name != "Vesper" && from.Region.Name != "Yew" &&//towns
                   from.Region.Name != "Wind" && from.Region.Name != "Serpent's Hold" &&//towns
                   from.Region.Name != "Skara Brae" && from.Region.Name != "Nujel'm" &&//towns
                   from.Region.Name != "Moonglow" && from.Region.Name != "Magincia" &&//towns
                   from.Region.Name != "Delucia" && from.Region.Name != "Papua" &&//towns
                   from.Region.Name != "Buccaneer's Den" && from.Region.Name != "Ocllo" &&//towns
                   from.Region.Name != "Gargoyle City" && from.Region.Name != "Mistas" &&//towns
                   from.Region.Name != "Montor" && from.Region.Name != "Alexandretta's Bowl" &&//towns
                   from.Region.Name != "Lenmir Anfinmotas" && from.Region.Name != "Reg Volon" &&//towns
                   from.Region.Name != "Bet-Lem Reg" && from.Region.Name != "Lake Shire" &&//towns
                   from.Region.Name != "Ancient Citadel" && from.Region.Name != "Luna" &&//towns
                   from.Region.Name != "Umbra" && //towns
                   from.Region.Name != "Moongates" &&
                   from.Region.Name != "Covetous" && from.Region.Name != "Deceit" &&//dungeons
                   from.Region.Name != "Despise" && from.Region.Name != "Destard" &&//dungeons
                   from.Region.Name != "Hythloth" && from.Region.Name != "Shame" &&//dungeons
                   from.Region.Name != "Wrong" && from.Region.Name != "Terathan Keep" &&//dungeons
                   from.Region.Name != "Fire" && from.Region.Name != "Ice" &&//dungeons
	  	   from.Region.Name != "Rock Dungeon" && from.Region.Name != "Spider Cave" &&//dungeons
	  	   from.Region.Name != "Spectre Dungeon" && from.Region.Name != "Blood Dungeon" &&//dungeons
	  	   from.Region.Name != "Wisp Dungeon" && from.Region.Name != "Ankh Dungeon" &&//dungeons
	  	   from.Region.Name != "Exodus Dungeon" && from.Region.Name != "Sorcerer's Dungeon" &&//dungeons
	  	   from.Region.Name != "Ancient Lair" && from.Region.Name != "Doom" &&//dungeons

	  	   from.Region.Name != "Britain Graveyard" && from.Region.Name != "Wrong Entrance" &&
	  	   from.Region.Name != "Covetous Entrance" && from.Region.Name != "Despise Entrance" &&
	  	   from.Region.Name != "Despise Passage" && from.Region.Name != "Jhelom Islands" &&
	  	   from.Region.Name != "Haven Island" && from.Region.Name != "Crystal Cave Entrance" &&
	  	   from.Region.Name != "Protected Island" && from.Region.Name != "Jail")
	  			   {
	  			   	return true;
	  			   }
	  			   else
	  			   {
	  			   	return false;
	  			   }
	  }
    private Point3D GetFireLocation(Mobile from)
    {
        if (from.Region is DungeonRegion)
            return Point3D.Zero;

        if (this.ControlMaster == null)
            return this.Location;

        ArrayList list = new ArrayList(4);

        AddOffsetLocation(from, 0, -1, list);
        AddOffsetLocation(from, -1, 0, list);
        AddOffsetLocation(from, 0, 1, list);
        AddOffsetLocation(from, 1, 0, list);

        if (list.Count == 0)
            return Point3D.Zero;

        int idx = Utility.Random(list.Count);
        return (Point3D)list[idx];
    }

    private void AddOffsetLocation(Mobile from, int offsetX, int offsetY, ArrayList list)
    {
        Map map = from.Map;

        int x = from.X + offsetX;
        int y = from.Y + offsetY;

        Point3D loc = new Point3D(x, y, from.Z);

        if (map.CanFit(loc, 1) && from.InLOS(loc))
        {
            list.Add(loc);
        }
        else
        {
            loc = new Point3D(x, y, map.GetAverageZ(x, y));

            if (map.CanFit(loc, 1) && from.InLOS(loc))
                list.Add(loc);
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Battle Speech
////////////////////////////////////////////////////////////////////////////////////////////////
    public override void OnDamage( int amount, Mobile from, bool willKill )
	{
		if ( from != null && willKill && /*amount > 5 &&*/ from.Player /*&& 5 > Utility.Random( 100 )*/ )
		{
			string[] toSay = new string[]
				{
					"{0}!!  This Sucks!",
					"{0}!!  I Shall fight for my honor!",
					"{0}!!  It's hardly worth dulling my blade on the likes of you!",
					"{0}!!  My sword shall bring justice, even after my death."
				};
				this.Say( true, String.Format( toSay[Utility.Random( toSay.Length )], from.Name ) );
                                from.Criminal = true;
                                from.Kills = 5;
			        from.Title = "Coward";
			        if ( from == this.ControlMaster)
				this.IsBonded = false;
		}
	base.OnDamage( amount, from, willKill );
	}
////////////////////////////////////////////////////////////////////////////////////////////////
//  Item Pickup
////////////////////////////////////////////////////////////////////////////////////////////////
    private DateTime m_NextPickup;
    public override void OnThink()
    {
        base.OnThink();
   
        if ( DateTime.Now < m_NextPickup )
            return;

        m_NextPickup = DateTime.Now + TimeSpan.FromSeconds( 2.5 + (6.0 * Utility.RandomDouble()) );

        Container pack = this.Backpack;

        if ( pack == null || !this.Alive)
            return;

        ArrayList list = new ArrayList();

        foreach ( Item item in this.GetItemsInRange( 2 ) )
        {
            if ( item.Movable )
                list.Add( item );
        }

        for ( int i = 0; i < list.Count; ++i )
        {
            Item item = (Item)list[i];

            if ( !pack.CheckHold( this, item, false, true ) )
                return;

            bool rejected;
            LRReason reject;

            NextActionTime = Core.TickCount;

            Lift( item, item.Amount, out rejected, out reject );

            if ( rejected )
                continue;

            Drop( this, Point3D.Zero );
        }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Resume Follow after Attack
////////////////////////////////////////////////////////////////////////////////////////////////
		if (this.BoundBrace.Hue == 1153)
		{
			this.BoundBrace.Name = this.Name;
			this.BoundBrace.Hue = 1170;
		}
        if (this.ControlTarget == null && this.ControlMaster != null && this.ControlOrder != OrderType.Stay)
        {
            ControlTarget = this.ControlMaster;
            ControlOrder = OrderType.Follow;
            this.Location = this.ControlMaster.Location;
            this.Map = this.ControlMaster.Map;
        }
        if (this.ControlMaster.InRange( this, 4 ) && this.ControlMaster != null)
        {
            this.Direction = this.ControlMaster.Direction;
        }
        if ( this.ControlMaster != null && this.ControlMaster.InRange( this, 20 ) && this.ControlOrder != OrderType.Stay)
        {
            // Place HOLDER
        }
        else if ( this.ControlMaster != null && this.ControlOrder != OrderType.Stay)
        {
            if (this.ControlOrder == OrderType.Attack)
                this.Say(this.ControlMaster.Name + ", I will not fight while you flee.");
            ControlTarget = this.ControlMaster;
            ControlOrder = OrderType.Follow;
            this.Location = this.ControlMaster.Location;
            this.Map = this.ControlMaster.Map;
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Pack Animal Methods
////////////////////////////////////////////////////////////////////////////////////////////////
	#region Pack Animal Methods
    public override bool OnBeforeDeath()
    {
        if ( this.Mount is Mobile )
            ((Mobile)this.Mount).Delete();


        if ( !base.OnBeforeDeath() )
            return false;

        PackAnimal.CombineBackpacks( this );

        return true;

    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Pack Access
////////////////////////////////////////////////////////////////////////////////////////////////
    public override bool IsSnoop( Mobile from )
    {
        if ( PackAnimal.CheckAccess( this, from ) )
            return false;

        return base.IsSnoop( from );
    }

////////////////////////////////////////////////////////////////////////////////////////////////
//  Share Intellegence (Mage)
////////////////////////////////////////////////////////////////////////////////////////////////


    /*public bool MegaSpell( Mobile from )
    {
        int combine_int = this.RawInt;
        if ( Spells.SpellHelper.AddStatOffset( this.ControlMaster, StatType.Int, combine_int, TimeSpan.FromMinutes( 1.0 ) ) )
        {
            this.ControlMaster.FixedEffect( 0x375A, 10, 15 );
            this.ControlMaster.PlaySound( 0x1E7 );
            return true;
        }
        else
            return false;
    }*/



////////////////////////////////////////////////////////////////////////////////////////////////
//  Drag & Drop Methods
////////////////////////////////////////////////////////////////////////////////////////////////

    public override bool OnDragDrop( Mobile from, Item item )
    {
        if ( CheckFeed( from, item ) )
            return true;
Container pack = this.Backpack;
        /*if ( PackAnimal.CheckAccess( this, from ) )
        {
            if ( !(item is RecallScroll || item is GateTravelScroll || item is SquireBrace || item is TribalPaint))
            {
                AddToBackpack( item );
                return true;
            }
        }
        if ( item == Bound )
        {
            item.Hue = 1170;
            this.Say("Let me recharge that Brace for you");
        }*/
        if (item is TribalPaint)
        {
            if (this.Female == true)
                this.BodyValue = 184;
            else
                this.BodyValue = 185;
            this.Hue = 0;
            this.Say("Wouldst my master want me to wear the paint of the savages?");
        }
        /*if (item is SquireBrace && item != Bound )
        {
            this.Say("I can not recharge that, it isn't my Brace.");
        }*/
        if ( item is RecallScroll )
        {
            int amount = item.Amount;
            if ( amount > (100 - Recall_C) )
            {
                item.Consume( 100 - Recall_C );
                Recall_C = 100;
            }
            else
            {
                Recall_C += amount;
                item.Delete();

                return true;
            }
        }

        if ( item is GateTravelScroll )
        {
            int amount2 = item.Amount;
            if ( amount2 > (100 - Gate_C) )
            {
                item.Consume( 100 - Gate_C );
                Gate_C = 100;
            }
            else
            {
                Gate_C += amount2;
                item.Delete();

                return true;
            }
        }
if ( item is BaseClothing && item.Layer == Layer.Pants && this.FindItemOnLayer( Layer.Pants ) == null || item.Layer == Layer.Shirt && this.FindItemOnLayer( Layer.Shirt ) == null || item.Layer == Layer.Helm && this.FindItemOnLayer( Layer.Helm ) == null || item.Layer == Layer.Gloves && this.FindItemOnLayer( Layer.Gloves ) == null || item.Layer == Layer.Neck && this.FindItemOnLayer( Layer.Neck ) == null || item.Layer == Layer.Arms && this.FindItemOnLayer( Layer.Arms ) == null || item.Layer == Layer.InnerTorso && this.FindItemOnLayer( Layer.InnerTorso ) == null || item.Layer == Layer.Shoes && this.FindItemOnLayer( Layer.Shoes ) == null || item.Layer == Layer.Cloak && this.FindItemOnLayer( Layer.Cloak ) == null || item.Layer == Layer.OuterTorso && this.FindItemOnLayer( Layer.OuterTorso ) == null )
			{
			this.Emote( "Thank you, tis wonderful" );
			pack.DropItem( item );
			this.AddItem( item );
				return true;
			}

			if ( item is BaseArmor && item.Layer == Layer.Pants && this.FindItemOnLayer( Layer.Pants ) == null || item.Layer == Layer.Shirt && this.FindItemOnLayer( Layer.Shirt ) == null || item.Layer == Layer.Helm && this.FindItemOnLayer( Layer.Helm ) == null || item.Layer == Layer.Gloves && this.FindItemOnLayer( Layer.Gloves ) == null || item.Layer == Layer.Neck && this.FindItemOnLayer( Layer.Neck ) == null || item.Layer == Layer.Arms && this.FindItemOnLayer( Layer.Arms ) == null || item.Layer == Layer.InnerTorso && this.FindItemOnLayer( Layer.InnerTorso ) == null || item.Layer == Layer.Shoes && this.FindItemOnLayer( Layer.Shoes ) == null )
			{
			this.Emote( "I shall put this to good use." );
			pack.DropItem( item );
			this.AddItem( item );
				return true;
			}

			if ( item is BaseShield && item.Layer == Layer.TwoHanded && this.FindItemOnLayer( Layer.TwoHanded ) == null )
			{
			this.Emote( "I shall put this to good use." );
			pack.DropItem( item );
			this.AddItem( item );
				return true;
			}

                        if ( item is BaseWeapon && item.Layer == Layer.OneHanded && this.FindItemOnLayer( Layer.OneHanded ) == null )
			{
			this.Emote( "I shall put this to good use." );
			pack.DropItem( item );
			this.AddItem( item );
				return true;
			}

                        if ( /*item is BaseJewel && item.Layer == Layer.Bracelet && this.FindItemOnLayer( Layer.Bracelet ) == null || */item.Layer == Layer.Ring && this.FindItemOnLayer( Layer.Ring ) == null || item.Layer == Layer.Earrings && this.FindItemOnLayer( Layer.Earrings ) == null || item.Layer == Layer.Neck && this.FindItemOnLayer( Layer.Neck ) == null)
			{
			this.Emote( "I shall put this to good use." );
			pack.DropItem( item );
			this.AddItem( item );
				return true;
			}
			if ( PackAnimal.CheckAccess( this, from ) )
			{
				AddToBackpack( item );
				return true;
			}

        return base.OnDragDrop( from, item );
    }

    public override bool CheckNonlocalDrop( Mobile from, Item item, Item target )
    {
        return PackAnimal.CheckAccess( this, from );
    }

    public override bool CheckNonlocalLift( Mobile from, Item item )
    {
        return PackAnimal.CheckAccess( this, from );
    }


    private class InternalTimer : Timer
    {
        private Item m_Item;

        public InternalTimer( Item item ) : base( TimeSpan.FromSeconds( 30.0 ) )
        {
            Priority = TimerPriority.OneSecond;
            m_Item = item;
        }

        protected override void OnTick()
        {
            m_Item.Delete();
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////
//  Double Click
////////////////////////////////////////////////////////////////////////////////////////////////

    public override void OnDoubleClick( Mobile from )
    {
        PackAnimal.TryPackOpen( this, from );
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

[CorpseName( "a Vengefull Spirit" )]
	public class VengefullSpirit : BaseCreature
	{
		[Constructable]
		public VengefullSpirit () : base( AIType.AI_Melee, FightMode.Evil, 10, 1, 0.2, 0.4 )
		{
			Name = "a Vengefull Spirit";
			Body = 403;
			BaseSoundID = 0x375;

			SetStr( 488, 620 );
			SetDex( 121, 170 );
			SetInt( 498, 657 );

			SetHits( 150, 350 );
			SpeechHue = 1161;
			SetDamage( 25, 45 );

			SetDamageType( ResistanceType.Physical, 75 );
			SetDamageType( ResistanceType.Energy, 25 );

			SetResistance( ResistanceType.Physical, 80, 90 );
			SetResistance( ResistanceType.Fire, 70, 80 );
			SetResistance( ResistanceType.Cold, 20, 30 );
			SetResistance( ResistanceType.Poison, 50, 60 );
			SetResistance( ResistanceType.Energy, 50, 60 );

			SetSkill( SkillName.EvalInt, 90.1, 100.0 );
			SetSkill( SkillName.Magery, 99.1, 100.0 );
			SetSkill( SkillName.Meditation, 90.1, 100.0 );
			SetSkill( SkillName.MagicResist, 200.5, 250.0 );
			SetSkill( SkillName.Tactics, 118.0, 190.0 );
			SetSkill( SkillName.Wrestling, 105.9, 190.0 );
			SetSkill( SkillName.Poisoning, 80.1, 100.0 );

			Fame = 24000;
			Karma = 24000;
			AddItem ( new HoodedShroudOfShadows() );
			VirtualArmor = 50;
			PackGold( 1000, 7000 );
			PackMagicItems( 6, 8 );
			PackMagicItems( 5, 8 );
			PackMagicItems( 8, 8 );
			PackMagicItems( 6, 8 );

		}
		public override bool ShowFameTitle{ get{ return false; } }
		public override int Meat{ get{ return 1; } }
		public override int TreasureMapLevel{ get{ return 5; } }
		public override Poison PoisonImmune{ get{ return Poison.Greater; } }
		public override Poison HitPoison{ get{ return (0.2 >= Utility.RandomDouble() ? Poison.Greater : Poison.Deadly); } }

		public void DrainLife()
		{
			ArrayList list = new ArrayList();

			foreach ( Mobile m in this.GetMobilesInRange( 2 ) )
			{
				if ( m == this || !CanBeHarmful( m ) )
					continue;

				if ( m is BaseCreature && (((BaseCreature)m).Controlled || ((BaseCreature)m).Summoned || ((BaseCreature)m).Team != this.Team) )
					list.Add( m );
				else if ( m.Player )
					list.Add( m );
			}

			foreach ( Mobile m in list )
			{
				DoHarmful( m );

				m.FixedParticles( 0x374A, 10, 15, 5013, 0x496, 0, EffectLayer.Waist );
				m.PlaySound( 0x231 );

				m.SendMessage( "You feel your self being drawn into death." );

				int toDrain = Utility.RandomMinMax( 10, 40 );

				Hits += toDrain;
				m.Damage( toDrain, this );
			}
		}

		public override void OnGaveMeleeAttack( Mobile defender )
		{
			base.OnGaveMeleeAttack( defender );
			if ( Utility.RandomDouble() >= 0.8 )
				this.Say( true, String.Format( "The Sword you weild is tainted with innocent blood. Now you shall die.") );
			if ( 0.2 >= Utility.RandomDouble() )
				DrainLife();
			if ( 0.2 >= Utility.RandomDouble() )
				SpawnSkeleton( defender );
		}

		public override void OnGotMeleeAttack( Mobile attacker )
		{
			base.OnGotMeleeAttack( attacker );

			if ( 0.1 >= Utility.RandomDouble() )
				DrainLife();
		}

		public void SpawnSkeleton( Mobile from )
		{
			BaseCreature skele;
			skele = new Skeleton();
			skele.Map = from.Map;
			skele.Location = from.Location;
			skele.Combatant = from;
		}

		public VengefullSpirit( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*public class NeonWep : BaseSword
	{
		public override WeaponAbility PrimaryAbility{ get{ return WeaponAbility.ShadowStrike; } }
		public override WeaponAbility SecondaryAbility{ get{ return WeaponAbility.BleedAttack; } }

		public override int AosStrengthReq{ get{ return 75; } }
		public override int AosMinDamage{ get{ return 25; } }
		public override int AosMaxDamage{ get{ return 35; } }
		public override int AosSpeed{ get{ return 65; } }

		public override int OldStrengthReq{ get{ return 75; } }
		public override int OldMinDamage{ get{ return 25; } }
		public override int OldMaxDamage{ get{ return 30; } }
		public override int OldSpeed{ get{ return 45; } }

		public override int DefHitSound{ get{ return 0x237; } }
		public override int DefMissSound{ get{ return 0x23A; } }

		public override int InitMinHits{ get{ return 255; } }
		public override int InitMaxHits{ get{ return 255; } }

    		private static int GetNeonHue()
    		{
			switch ( Utility.Random( 4 ) )
			{
				default:
				case 0: return 1170;
				case 1: return 1370;
				case 2: return 1161;
				case 3: return 1160;
			}
		}


		[Constructable]
		public NeonWep() : base( 0xF5E )
		{
			this.Weight = 0.0;
			this.Hue = GetNeonHue();
			this.Name = "A Neon Sword";

			if (this.Hue == 1170)
				{
					this.WeaponAttributes.HitLightning = 50;
					this.WeaponAttributes.HitEnergyArea = 25;
					this.Name = "the Squire's Blade of Power";
					this.Attributes.AttackChance = 35;
				}
				else if (this.Hue == 1370)
				{
					this.WeaponAttributes.HitPoisonArea = 65;
					this.Name = "the Squire's Toxic Blade" ;
					this.Attributes.AttackChance = 35;
				}
				else if (this.Hue == 1161)
				{
					this.Attributes.SpellChanneling = 1;
					this.Attributes.CastSpeed = 2;
					this.Attributes.CastRecovery = 2;
					this.Attributes.RegenMana = 8;
					this.WeaponAttributes.MageWeapon = 1;
					this.Name = "the Squires Blade of Sorcery";
				}
				else if (this.Hue == 1160)
				{
					this.WeaponAttributes.HitColdArea = 65;
					this.Attributes.AttackChance = 35;
					this.Name = "the Squire's Freezing Blade";
				}
		}

		public override void OnHit( Mobile attacker, Mobile defender )
		{
			if ( Utility.RandomDouble() >= 0.9 )
				if ( Utility.RandomDouble() >= 0.5 )
					if ( attacker.Criminal )
						Spawnhell( attacker );
			base.OnHit( attacker, defender );
		}

		public override void OnDoubleClick( Mobile from )
		{
		}

		public void Spawnhell( Mobile from )
		{
			BaseCreature hell;
			hell = new VengefullSpirit();
			hell.Map = from.Map;
			hell.Location = from.Location;
			hell.Combatant = from;
		}

		public NeonWep( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}*/

    public override void OnSingleClick( Mobile from )
    {
    }
    public override void GetProperties( ObjectPropertyList list )
    {
        base.GetProperties( list );
        //list.Add( 1060660, "attack charges\t{0}", this.AttackCharges );
        list.Add( 1060659, "loyalty\t{0}", this.Loyalty );
        list.Add( 1060658, "recall charges\t{0}", this.RecallCharges );
        list.Add( 1060662, "gate charges\t{0}", this.GateCharges );
    }
    public override void GetContextMenuEntries(Mobile from, List<ContextMenuEntry> list)
    {
        base.GetContextMenuEntries( from, list );

        PackAnimal.GetContextMenuEntries( this, from, list );
    }
		#endregion
////////////////////////////////////////////////////////////////////////////////////////////////
//  End of Base Squire
////////////////////////////////////////////////////////////////////////////////////////////////
    public override FoodType FavoriteFood{ get{ return FoodType.Gold; } }
    public Squire( Serial serial ) : base( serial )
    {
    }
    public override void Serialize( GenericWriter writer )
    {
        base.Serialize( writer );

        writer.Write( (int) 0 );
        writer.Write( (int) attitude );
        writer.Write( (int) motive );
        writer.Write( (int) age );
        writer.Write( (Item) Bound );
        //writer.Write( (int) Attack_C );
        writer.Write( (int) Recall_C );
        writer.Write( (int) Gate_C );
        writer.Write( (Point3D) HouseLocation );
        writer.Write( (Map) HouseMap );

    }
    public override void Deserialize( GenericReader reader )
    {
        base.Deserialize( reader );
        int version = reader.ReadInt();

        switch ( version )
        {
        case 0:
            {
                motive = (SquireMotivation)reader.ReadInt();
                attitude = (SquirePersonality)reader.ReadInt();
                age = (SquireAge)reader.ReadInt();
                Bound = reader.ReadItem();
                //Attack_C = reader.ReadInt();
                Recall_C = reader.ReadInt();
                Gate_C = reader.ReadInt();
                HouseLocation = reader.ReadPoint3D();
                HouseMap = reader.ReadMap();

                break;
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////
//  Bracelet of Squire Summoning
///////////////////////////////////////////////////////////////////////////////////////////////
public class SquireBrace : GoldBracelet, IRewardItem
{

    private bool m_IsRewardItem;
    [CommandProperty(AccessLevel.GameMaster)]
    public bool IsRewardItem
    {
        get { return m_IsRewardItem; }
        set { m_IsRewardItem = value; InvalidateProperties(); }
    }
             
    public Mobile Bound_S;
    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public Mobile BoundSquire
    {
        get
        {
            return Bound_S;
        }
        set
        {
            Bound_S = value;
            InvalidateProperties();
        }
    }
    public bool Used;
    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public bool squire_created
    {
        get{return Used;}
        set{Used = value;}
    }
    public bool Active;
    [CommandProperty( AccessLevel.Counselor, AccessLevel.GameMaster )]
    public bool Status
    {
        get{return Active;}
        set{Active = value;}
    }
    [Constructable]
    public SquireBrace()
    {
        Name = "a Bracelet of Squire Summoning";
        Hue = 1373;
        LootType = LootType.Blessed;
    	Used = false;
    	Active = true;
    }

    public override void OnDoubleClick( Mobile from )
    {
        if (m_IsRewardItem && !RewardSystem.CheckIsUsableBy(from, this, null))
        {
            from.SendMessage("This does not belong to you!!");
            return;
        }
        if ( Parent != from )
        {
            from.SendMessage( 22, "You must equip this item to use it." );
        }
        else
        {
            if ( this.squire_created == false )
            {
                MakeSquire( from );
                this.Hue = 1170;
            	this.squire_created = true;
            	this.Status = true;
            }
            else if ( this.squire_created == true /*&& this.Status == true*/ )
            {
                //SquireStable(from);
                from.Target = new ShrinkCmdTarget();
                from.SendMessage( "What do you wish to shrink?" );
            	//this.Name = this.Name + " [Resting]";
                this.Hue = 1153;     /// Set inactive Hue Here
                //this.Status = false;
            }
            /*else if ( this.Hue == 1153 ) // added
				{
					Item[] Gold = from.Backpack.FindItemsByType( typeof( Gold ) );
					if ( from.Backpack.ConsumeTotal( typeof( Gold ), 1000 ) ) // Edit Recharge Cost 1
					{
					from.SendMessage( "You recharge the Bracelet" );
					this.Hue = 1170;
					}
					else
					{
					from.SendMessage( "You need 1000 Gold to recharge this." ); // Edit Recharge Cost 2
					}
				}*/
            else if ( this.squire_created == true && this.Status == false && from.Followers + 2 <= from.FollowersMax)
            {
    			//SquireClaim(from);
            	this.Hue = 1170;     /// Set Active Hue Here
            	this.Name = this.BoundSquire.Name;
            	this.Status = true;
            }
            else if ( this.squire_created == true && this.Status == false )
        		from.SendMessage("You need 2 available Control Slots for a Squire");
        }
    }
// This class is using the Shrink system
		private class ShrinkCmdTarget : Target
		{
			public ShrinkCmdTarget() : base( 15, false, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object targ )
			{
                             BaseCreature pet = targ as BaseCreature;
                          if ( targ is Squire && pet.ControlMaster == from)
                                {
                                //this.Hue = 1170;     /// Set Active Hue Here
				ShrinkFunctions.Shrink( from, targ, false );
                                }
			}
		}

//// end: Edited for shrink
	/*public void SquireStable( Mobile from )
	{
		BaseCreature pet = BoundSquire as BaseCreature;
                pet.ControlTarget = null;
		pet.ControlOrder = OrderType.Stay;
                pet.SetControlMaster( null );
		pet.SummonMaster = null;
                pet.Blessed = true;
                pet.IsStabled = true;
		this.BoundSquire.Internalize();
		from.Stabled.Add( this.BoundSquire );
			
	}
	public void SquireClaim (Mobile from)
	{
		if ( Deleted || !from.CheckAlive() )
				return;

			
			int stabled = 0;
			for ( int i = 0; i < from.Stabled.Count; ++i )
			{
				BaseCreature pet = from.Stabled[i] as BaseCreature;
				if ( pet == null || pet.Deleted )
				{
					pet.IsStabled = false;
                                        pet.Blessed = false;
					from.Stabled.RemoveAt( i );
					--i;
					continue;
				}
				++stabled;
				if ( (from.Followers + pet.ControlSlots) <= from.FollowersMax && pet == this.BoundSquire)
				{
					pet.SetControlMaster( from );
					if ( pet.Summoned )
					pet.SummonMaster = from;
					pet.ControlTarget = from;
                                        pet.Blessed = false;
					pet.ControlOrder = OrderType.Follow;
					pet.Location = from.Location;
					pet.Map = from.Map;
					pet.IsStabled = false;
					from.Stabled.RemoveAt( i );
					--i;
					
				}
			}
	}*/
    public void MakeSquire( Mobile from )
    {
        Squire newsquire;
        newsquire = new Squire();
        newsquire.Map = from.Map;
        newsquire.Location = from.Location;
        newsquire.Controlled = true;
        //newsquire.Loyalty = MaxLoyalty.WonderfullyHappy;
        newsquire.ControlTarget = from;
        newsquire.ControlMaster = from;
        this.BoundSquire = newsquire;
        newsquire.Bound = this;
    	newsquire.HomeLocation = from.Location;
    	newsquire.HomeMap = from.Map;

        switch(Utility.Random(2))
        {
        case 0:
            {
                newsquire.Female = true;
                newsquire.Body = 0x191;
                newsquire.Hue = 33791;

                newsquire.BaseSoundID = 806;
                newsquire.SpeechHue = 1161;
                newsquire.CanHearGhosts = true;
                newsquire.SetStr( 100 );
                newsquire.SetDex( 65 );
                newsquire.SetInt( 200 );
                newsquire.SetDamage( 15, 45 );
                newsquire.SetHits( 215 );
                newsquire.SetStam( 110 );
                newsquire.SetMana( 100 );
                switch ( Utility.Random( 3 ) )
                {
                case 0: AddItem( new TwoPigTails( Utility.RandomHairHue() ) ); break;
                case 1:	AddItem( new BunsHair( Utility.RandomHairHue() ) ); break;
                case 2: AddItem( new PonyTail( Utility.RandomHairHue() ) ); break;
                }
                break;
            }
        case 1:
            {
                newsquire.Female = false;
                newsquire.Body = 0x190;
                newsquire.Hue = 33791;
                newsquire.BaseSoundID = 1068;
                newsquire.SpeechHue = 1161;
                newsquire.CanHearGhosts = true;
                newsquire.SetStr( 100 );
                newsquire.SetDex( 65 );
                newsquire.SetInt( 200 );
                newsquire.SetDamage( 15, 45 );
                newsquire.SetHits( 215 );
                newsquire.SetStam( 110 );
                newsquire.SetMana( 100 );
                switch ( Utility.Random( 4 ) )
                {
                case 0: AddItem( new ShortHair( Utility.RandomHairHue() ) ); break;
                case 1: AddItem( new Afro( Utility.RandomHairHue() ) ); break;
                case 2: AddItem( new ReceedingHair( Utility.RandomHairHue() ) ); break;
                case 3: AddItem( new KrisnaHair( Utility.RandomHairHue() ) ); break;
                }
                break;
            }
        default:
            {
                newsquire.Female = false;
                break;
            }

        }
        newsquire.BondingBegin = DateTime.Now;
        newsquire.OwnerAbandonTime = DateTime.Now + TimeSpan.FromDays(365);
        newsquire.IsBonded = true;
        newsquire.ControlOrder = OrderType.Follow;
        if (newsquire.Female == true)
        {
            newsquire.Name = NameList.RandomName( "female" );
            this.Name = newsquire.Name;
        }
        else
        {
            newsquire.Name = NameList.RandomName( "male" );
            this.Name = newsquire.Name;
        }
    }
    public override void OnDelete()
    {
        if (this.BoundSquire != null)
            this.BoundSquire.Delete();

    }
    public SquireBrace( Serial serial ) : base( serial )
    {
    }
    public override void Serialize( GenericWriter writer )
    {
        base.Serialize( writer );

        writer.Write( (int) 1 );
        writer.Write((bool)m_IsRewardItem);
        writer.Write( (Mobile) Bound_S );
    	writer.Write( (bool) Used );
    	writer.Write( (bool) Active );
    }
    public override void Deserialize(GenericReader reader)
    {
        base.Deserialize( reader );

        int version = reader.ReadInt();
        switch ( version )
        {
        case 0:
            {
                m_IsRewardItem = reader.ReadBool();
                Bound_S = reader.ReadMobile();
            	break;
            }
         case 1:
            {
                Bound_S = reader.ReadMobile();
                Used = reader.ReadBool();
            	Active = reader.ReadBool();
                break;
            }
        }

    }
}
}
